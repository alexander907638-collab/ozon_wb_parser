"""FastAPI приложение."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from parser.common.urls import detect_marketplace, parse_url, split_lines

from .tasks import TaskManager


load_dotenv()

BASE_DIR = Path(__file__).parent
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))

app = FastAPI(title="MP Q&A Parser", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")

manager = TaskManager(OUTPUT_DIR)


# ---------- Pages ----------

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Главная — форма + список задач."""
    tasks = [t.to_dict() for t in manager.get_recent()]
    return templates.TemplateResponse(
        request, "index.html", {"tasks": tasks}
    )


@app.get("/task/{task_id}", response_class=HTMLResponse)
async def task_detail(request: Request, task_id: str):
    """Страница задачи: метаданные + просмотр items."""
    task = manager.get(task_id)
    if not task:
        raise HTTPException(404, "Задача не найдена")

    # JSON-файл с items (для предпросмотра)
    items_file = next(
        (f for f in task.files if f.endswith(".json") and "report" not in f),
        None,
    )
    items = manager.load_items_from_file(items_file) if items_file else []

    return templates.TemplateResponse(
        request,
        "task_detail.html",
        {
            "task": task.to_dict(),
            "items_total": len(items),
            "items_file": items_file,
        },
    )


# ---------- API ----------

@app.post("/run")
async def run_parser(
    urls_text: str = Form(""),
    urls_file: UploadFile | None = File(None),
    debug: str = Form(""),
):
    """
    Создать задачу. Источники URL: textarea и/или txt-файл.
    Если оба — конкатенируем.
    """
    parts: list[str] = []
    if urls_text:
        parts.append(urls_text)

    if urls_file and urls_file.filename:
        try:
            raw = (await urls_file.read()).decode("utf-8", errors="ignore")
            parts.append(raw)
        except Exception as e:
            raise HTTPException(400, f"Не удалось прочитать файл: {e}")

    combined_text = "\n".join(parts)
    urls = split_lines(combined_text)
    if not urls:
        raise HTTPException(400, "Не передано ни одного URL")

    # быстрая валидация — сразу отметим, какие URL не выглядят как товары
    # (короткие ozon.ru/t/ пройдут проверку, потому что мы их распарсим после резолва)
    for u in urls:
        mp = detect_marketplace(u)
        if mp is None:
            raise HTTPException(
                400,
                f"URL не относится к Ozon/WB: {u}. "
                f"Поддерживаются ozon.ru и wildberries.ru",
            )

    debug_enabled = debug.strip().lower() in ("on", "true", "1", "yes")
    task = manager.enqueue(urls, debug=debug_enabled)
    return RedirectResponse(f"/task/{task.id}", status_code=303)


@app.get("/api/tasks")
async def api_tasks() -> JSONResponse:
    """Polling — список задач."""
    return JSONResponse([t.to_dict() for t in manager.get_recent()])


@app.get("/api/tasks/{task_id}")
async def api_task(task_id: str) -> JSONResponse:
    """Polling — одна задача."""
    task = manager.get(task_id)
    if not task:
        raise HTTPException(404, "Не найдена")
    return JSONResponse(task.to_dict())


@app.get("/api/tasks/{task_id}/items")
async def api_task_items(
    task_id: str,
    page: int = 1,
    per_page: int = 50,
    item_type: str = "",
    search: str = "",
) -> JSONResponse:
    """
    Пагинированные items для UI.
    Фильтры: item_type (question|review|answer), search (по тексту).
    """
    task = manager.get(task_id)
    if not task:
        raise HTTPException(404, "Не найдена")

    items_file = next(
        (f for f in task.files if f.endswith(".json") and "report" not in f),
        None,
    )
    if not items_file:
        return JSONResponse({"items": [], "total": 0, "page": page, "per_page": per_page})

    all_items = manager.load_items_from_file(items_file)

    # фильтры
    filtered = all_items
    if item_type:
        filtered = [i for i in filtered if i.get("item_type") == item_type]
    if search:
        s = search.lower()
        filtered = [
            i for i in filtered
            if s in (i.get("text") or "").lower()
            or s in (i.get("answer_text") or "").lower()
            or s in (i.get("author") or "").lower()
        ]

    total = len(filtered)
    per_page = max(10, min(200, per_page))
    page = max(1, page)
    start = (page - 1) * per_page
    end = start + per_page
    page_items = filtered[start:end]

    # счётчики типов — для UI бейджей
    from collections import Counter
    type_counts = dict(Counter(i.get("item_type", "") for i in all_items))

    return JSONResponse({
        "items": page_items,
        "total": total,
        "total_unfiltered": len(all_items),
        "type_counts": type_counts,
        "page": page,
        "per_page": per_page,
        "total_pages": max(1, (total + per_page - 1) // per_page),
    })


@app.get("/files/{name}")
async def get_file(name: str):
    """Скачать файл (CSV/JSON)."""
    if "/" in name or ".." in name or "\\" in name:
        raise HTTPException(400, "Bad filename")
    path = OUTPUT_DIR / name
    if not path.exists() or not path.is_file():
        raise HTTPException(404, "Файл не найден")
    return FileResponse(path, filename=name)


@app.get("/healthz")
async def healthz():
    return {"status": "ok"}
