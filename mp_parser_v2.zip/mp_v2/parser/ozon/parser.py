"""
Парсер Q&A для Ozon.

Основной путь:
  GET https://api.ozon.ru/composer-api.bx/page/json/v2?url=/product/{id}/questions/
  Headers: User-Agent мобильного приложения (важно — обходит CF)
  Ответ: JSON с полем widgetStates, среди которых есть webListQuestions-*

Fallback (если основной endpoint вернул нерабочий ответ):
  GET https://www.ozon.ru/product/{id}/questions/
  Парсинг HTML — ищем <div data-question-id="..."> и текст внутри.
  ВНИМАНИЕ: HTML-классы (jw7_24, w8j_24 и т.п.) меняются. Полагаемся
  ТОЛЬКО на семантические атрибуты (data-question-id, data-widget).

Структура ответа composer-api подтверждена несколькими публичными парсерами
(JTJag/ozon-sellers-parser, Churkashh/ozon-pinneaples). Если структура
на конкретном проде окажется иной — включи debug-режим (флаг в HttpClient),
парсер сохранит сырой ответ в файл.
"""
from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import urljoin

from ..common.http import HttpClient, HttpError, OZON_MOBILE_UA
from ..common.types import Product, QAItem, RateLimiter


COMPOSER_API = "https://api.ozon.ru/composer-api.bx/page/json/v2"
PRODUCT_HTML_BASE = "https://www.ozon.ru"


# Кандидаты ключей виджета вопросов в widgetStates.
# Названия могут варьироваться между ревизиями — поэтому ищем по подстроке.
QUESTIONS_WIDGET_PATTERNS = [
    "webListQuestions",
    "webProductQuestions",
    "questionsList",
    "webQuestionsList",
]


def _find_widgets(widget_states: dict[str, Any], patterns: list[str]) -> list[Any]:
    """Найти все виджеты, имя которых содержит любой из паттернов."""
    found = []
    for key, raw in widget_states.items():
        if not any(p in key for p in patterns):
            continue
        if isinstance(raw, str):
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError:
                continue
            found.append((key, parsed))
        elif isinstance(raw, dict):
            found.append((key, raw))
    return found


def _coerce_str(value: Any) -> str:
    """Безопасное преобразование к строке."""
    if value is None:
        return ""
    if isinstance(value, (str, int, float)):
        return str(value)
    return ""


def _extract_author(node: Any) -> str:
    """Достать имя автора из разных форматов node.author."""
    if isinstance(node, dict):
        for k in ("name", "fullName", "displayName"):
            if node.get(k):
                return str(node[k])
    if isinstance(node, str):
        return node
    return ""


class OzonParser:
    """Парсер Q&A одного товара Ozon."""

    def __init__(self, client: HttpClient, limiter: RateLimiter):
        self.client = client
        self.limiter = limiter

    async def fetch_product_meta(self, product_id: str) -> dict[str, Any]:
        """
        Получить базовую инфо о товаре (имя) через composer-api.
        Возвращает {} если не удалось.
        """
        await self.limiter.wait()
        params = {"url": f"/product/{product_id}/"}
        headers = {"User-Agent": OZON_MOBILE_UA, "Accept": "application/json"}
        try:
            data = await self.client.get_json(
                COMPOSER_API, params=params, headers=headers
            )
        except HttpError:
            return {}

        # имя ищем в разных местах:
        # 1) в seo title
        # 2) в widgetStates['webProductHeading-*']
        ws = data.get("widgetStates") or {}
        for key, raw in ws.items():
            if "webProductHeading" not in key and "webStickyProducts" not in key:
                continue
            try:
                parsed = json.loads(raw) if isinstance(raw, str) else raw
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, dict) and parsed.get("title"):
                return {"name": str(parsed["title"])}

        # SEO title как fallback
        seo = data.get("seo") or {}
        if seo.get("title"):
            return {"name": str(seo["title"])}

        return {}

    async def fetch_questions(self, product: Product) -> list[QAItem]:
        """
        Получить все вопросы и ответы по товару.
        Стратегия: composer-api → HTML fallback.
        """
        # Попытка 1: composer-api
        items = await self._fetch_via_composer_api(product)
        if items:
            return items

        # Попытка 2: HTML
        return await self._fetch_via_html(product)

    async def _fetch_via_composer_api(self, product: Product) -> list[QAItem]:
        """Основной путь: composer-api с пагинацией."""
        all_items: list[QAItem] = []
        page = 1
        max_pages = 50  # safety guard

        headers = {"User-Agent": OZON_MOBILE_UA, "Accept": "application/json"}

        while page <= max_pages:
            await self.limiter.wait()
            internal_url = f"/product/{product.product_id}/questions/"
            if page > 1:
                internal_url += f"?page={page}"
            params = {"url": internal_url}

            try:
                data = await self.client.get_json(
                    COMPOSER_API, params=params, headers=headers
                )
            except HttpError as e:
                # на первой странице — фатально, идём в fallback
                if page == 1:
                    print(f"[ozon] composer-api failed for {product.product_id}: {e}")
                    return []
                # на последующих — просто прерываем пагинацию
                break

            widget_states = data.get("widgetStates") or {}
            widgets = _find_widgets(widget_states, QUESTIONS_WIDGET_PATTERNS)

            if not widgets:
                # Возможно, у товара 0 вопросов или структура изменилась.
                # На первой странице если ничего нет — пробуем HTML fallback.
                if page == 1 and not all_items:
                    return []
                break

            page_items = self._extract_items_from_widgets(widgets, product)
            if not page_items:
                # больше нет вопросов
                break

            # дедупликация по item_id (если несколько виджетов дают пересечения)
            existing_ids = {i.item_id for i in all_items if i.item_type == "question"}
            new_items = [
                i for i in page_items
                if i.item_type != "question" or i.item_id not in existing_ids
            ]
            if not new_items:
                break
            all_items.extend(new_items)

            # есть ли следующая страница? Если в JSON есть pagination/nextPage
            # то используем его, иначе просто инкрементируем
            has_more = self._has_more_pages(widget_states, page, len(page_items))
            if not has_more:
                break
            page += 1

        return all_items

    def _has_more_pages(
        self, widget_states: dict, current_page: int, last_page_count: int
    ) -> bool:
        """Эвристика наличия следующей страницы."""
        # Если виджет вернул мало записей (< 20), скорее всего конец
        if last_page_count < 10:
            return False
        # Иначе пробуем ещё одну страницу (защита через max_pages)
        return True

    def _extract_items_from_widgets(
        self, widgets: list[tuple[str, Any]], product: Product
    ) -> list[QAItem]:
        """Достать QAItem из всех найденных виджетов."""
        items: list[QAItem] = []
        for widget_key, widget_data in widgets:
            if not isinstance(widget_data, dict):
                continue

            # Поле с массивом вопросов может называться по-разному
            questions = (
                widget_data.get("questions")
                or widget_data.get("items")
                or widget_data.get("list")
                or []
            )
            if not isinstance(questions, list):
                continue

            for q in questions:
                if not isinstance(q, dict):
                    continue
                items.extend(self._parse_question(q, product))

        return items

    def _parse_question(self, q: dict, product: Product) -> list[QAItem]:
        """Один вопрос → один QAItem (+ доп. ответы как отдельные items)."""
        out: list[QAItem] = []

        q_id = _coerce_str(q.get("id") or q.get("questionId"))
        if not q_id:
            return out

        q_text = _coerce_str(
            q.get("text") or q.get("question") or q.get("content")
        )
        q_author = _extract_author(q.get("author"))
        if not q_author:
            q_author = _coerce_str(q.get("authorName"))
        q_date = _coerce_str(
            q.get("createdAt") or q.get("publishedAt") or q.get("date")
        )

        # Ответы. Может быть answers[] или firstAnswer/answer
        answers = q.get("answers")
        if not answers and q.get("answer"):
            answers = [q["answer"]]
        if not isinstance(answers, list):
            answers = []

        # Первый ответ — в основной item
        first_answer = answers[0] if answers else None
        first_answer_text = ""
        first_answer_author = ""
        first_answer_date = ""
        if isinstance(first_answer, dict):
            first_answer_text = _coerce_str(first_answer.get("text"))
            first_answer_author = _extract_author(first_answer.get("author"))
            first_answer_date = _coerce_str(
                first_answer.get("createdAt") or first_answer.get("date")
            )

        out.append(QAItem(
            marketplace="ozon",
            product_id=product.product_id,
            product_name=product.name,
            product_url=product.url,
            item_type="question",
            item_id=q_id,
            text=q_text,
            author=q_author,
            created_at=q_date,
            answer_text=first_answer_text,
            answer_author=first_answer_author,
            answer_at=first_answer_date,
        ))

        # Дополнительные ответы — отдельными записями
        for ans in answers[1:]:
            if not isinstance(ans, dict):
                continue
            out.append(QAItem(
                marketplace="ozon",
                product_id=product.product_id,
                product_name=product.name,
                product_url=product.url,
                item_type="answer",
                item_id=_coerce_str(ans.get("id")),
                text=_coerce_str(ans.get("text")),
                author=_extract_author(ans.get("author")),
                created_at=_coerce_str(ans.get("createdAt") or ans.get("date")),
                parent_id=q_id,
            ))

        return out

    # ---------- HTML fallback ----------

    async def _fetch_via_html(self, product: Product) -> list[QAItem]:
        """
        Fallback: парсим HTML страницы вопросов.
        Опираемся ТОЛЬКО на семантические атрибуты:
        - data-widget="webListQuestions" — контейнер
        - data-question-id="..." — id вопроса
        Текст вопроса/ответа достаём через позиционный обход внутренних блоков
        (классы рандомные, на них полагаться нельзя).
        """
        await self.limiter.wait()
        url = f"{PRODUCT_HTML_BASE}/product/{product.product_id}/questions/"
        try:
            _, html = await self.client.get_text(url)
        except HttpError as e:
            print(f"[ozon] HTML fallback failed for {product.product_id}: {e}")
            return []

        return self._parse_questions_html(html, product)

    def _parse_questions_html(self, html: str, product: Product) -> list[QAItem]:
        """
        Парсим HTML без BeautifulSoup, чтобы не плодить зависимости.
        Стратегия:
        1) Находим все <div data-question-id="N" — берём позицию <
        2) Берём содержимое до следующего <div data-question-id или конца контейнера
        3) Чистим теги, эвристически делим на вопрос/автор/ответ
        """
        items: list[QAItem] = []

        # Ищем именно открывающий тег с атрибутом — берём позицию <
        # ([^>]*?) — любые другие атрибуты до или после
        pattern = re.compile(
            r'<div\s[^>]*?data-question-id="(\d+)"[^>]*>',
            re.IGNORECASE,
        )
        positions: list[tuple[int, int, str]] = []  # (tag_start, content_start, q_id)
        for m in pattern.finditer(html):
            positions.append((m.start(), m.end(), m.group(1)))

        if not positions:
            return items

        # sentinel
        positions.append((len(html), len(html), ""))

        for i in range(len(positions) - 1):
            _, content_start, q_id = positions[i]
            content_end, _, _ = positions[i + 1]
            chunk = html[content_start:content_end]

            texts = self._strip_html_to_lines(chunk)
            if not texts:
                continue

            # Эвристика по структуре, видимой на скриншоте Ozon:
            #   [дата] [возможно: имя бренда] [текст вопроса] [имя автора вопроса]
            #   [блок ответа: "Лучший ответ" | имя продавца | дата | текст ответа]
            #
            # Самый длинный текст из первых 5 строк — обычно это вопрос
            # Самый длинный текст из остатка — обычно это ответ продавца
            #
            # Дата опознаётся по паттерну "DD месяц YYYY"
            date_re = re.compile(r"\d{1,2}\s+[а-яё]+\s+\d{4}", re.IGNORECASE)

            # отделим даты от обычного текста
            non_dates = [t for t in texts if not date_re.fullmatch(t)]
            if not non_dates:
                continue

            # вопрос: самая длинная строка из первой половины
            half = max(2, len(non_dates) // 2)
            first_half = non_dates[:half]
            second_half = non_dates[half:]

            question_text = max(first_half, key=len) if first_half else ""
            q_idx = non_dates.index(question_text)

            # автор вопроса: следующая короткая строка после question_text
            author = ""
            for t in non_dates[q_idx + 1:q_idx + 3]:
                if 1 < len(t) < 60 and "ответ" not in t.lower():
                    author = t
                    break

            # ответ продавца: самая длинная строка во второй половине
            answer_text = ""
            answer_author = ""
            if second_half:
                # фильтруем служебные пометки
                candidates = [
                    t for t in second_half
                    if t.lower() not in ("лучший ответ", "ответ продавца")
                ]
                if candidates:
                    answer_text = max(candidates, key=len)
                    a_idx = non_dates.index(answer_text)
                    # имя отвечающего — короткая строка перед текстом ответа
                    for t in reversed(non_dates[:a_idx]):
                        if (
                            1 < len(t) < 60
                            and t != author
                            and t != question_text
                            and "ответ" not in t.lower()
                        ):
                            answer_author = t
                            break
                    # если ответ совпал с вопросом (мало ответов в чанке) — обнуляем
                    if answer_text == question_text:
                        answer_text = ""
                        answer_author = ""

            items.append(QAItem(
                marketplace="ozon",
                product_id=product.product_id,
                product_name=product.name,
                product_url=product.url,
                item_type="question",
                item_id=q_id,
                text=question_text,
                author=author,
                answer_text=answer_text,
                answer_author=answer_author,
            ))

        return items

    @staticmethod
    def _strip_html_to_lines(chunk: str) -> list[str]:
        """Вырезать текст из HTML-чанка, вернуть список непустых строк."""
        # Убираем script/style целиком
        chunk = re.sub(
            r"<(script|style)[^>]*>.*?</\1>", "", chunk, flags=re.DOTALL
        )
        # Заменяем теги на переносы
        text = re.sub(r"<[^>]+>", "\n", chunk)
        # HTML-сущности
        text = (
            text.replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", '"')
                .replace("&#39;", "'")
        )
        lines = [ln.strip() for ln in text.split("\n")]
        return [ln for ln in lines if ln and len(ln) > 1]
