"""
Pipeline парсинга Q&A.

Один вход — список URL (короткие/длинные, Ozon/WB вперемешку).
Один выход — список QAItem.

Поддерживает callback `on_progress(current, total, message)` для отображения
прогресса в UI/CLI.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .common.http import HttpClient
from .common.types import Product, QAItem, RateLimiter
from .common.urls import (
    detect_marketplace,
    is_ozon_short,
    parse_ozon_canonical,
    parse_url,
    parse_wb,
)
from .ozon import OzonParser
from .wb import WBParser


ProgressCallback = Callable[[int, int, str], None]


@dataclass
class ParseResult:
    """Результат обработки одного URL."""
    url: str
    success: bool
    product_id: str = ""
    marketplace: str = ""
    items_count: int = 0
    error: str = ""


@dataclass
class PipelineConfig:
    """Конфиг пайплайна."""
    proxy: str | None = None
    ozon_delay: float = 1.5
    wb_delay: float = 0.5
    request_timeout: int = 30
    debug_dir: str | None = None  # путь для дампа сырых ответов


class ParserPipeline:
    """
    Главный оркестратор. Использовать так:

        pipeline = ParserPipeline(config)
        items, results = await pipeline.run(urls, on_progress=cb)
    """

    def __init__(self, config: PipelineConfig):
        self.config = config

    async def run(
        self,
        urls: list[str],
        on_progress: ProgressCallback | None = None,
    ) -> tuple[list[QAItem], list[ParseResult]]:
        """
        Обработать список URL. Возвращает (все_items, по_url_результаты).
        """
        all_items: list[QAItem] = []
        results: list[ParseResult] = []

        # отдельные лимитеры по площадкам (чтобы Ozon и WB не блокировали друг друга)
        ozon_limiter = RateLimiter(self.config.ozon_delay)
        wb_limiter = RateLimiter(self.config.wb_delay)

        from pathlib import Path
        debug_dir = Path(self.config.debug_dir) if self.config.debug_dir else None

        # Один HttpClient на весь pipeline — общий пул соединений
        async with HttpClient(
            proxy=self.config.proxy,
            timeout=self.config.request_timeout,
            debug_dir=debug_dir,
        ) as client:
            ozon_parser = OzonParser(client, ozon_limiter)
            wb_parser = WBParser(client, wb_limiter)

            total = len(urls)
            for i, raw_url in enumerate(urls, start=1):
                if on_progress:
                    on_progress(i, total, f"Обработка {raw_url[:60]}")

                result = ParseResult(url=raw_url, success=False)
                try:
                    items = await self._process_one(
                        raw_url, client, ozon_parser, wb_parser
                    )
                    all_items.extend(items)
                    result.success = True
                    result.items_count = len(items)
                    if items:
                        result.product_id = items[0].product_id
                        result.marketplace = items[0].marketplace
                    else:
                        # ноль вопросов — тоже успех (не ошибка)
                        parsed = await self._safe_parse(raw_url, client)
                        if parsed:
                            result.product_id = parsed.product_id
                            result.marketplace = parsed.marketplace
                except Exception as e:
                    result.error = f"{type(e).__name__}: {e}"

                results.append(result)

            if on_progress:
                on_progress(
                    total, total,
                    f"Готово: {len(all_items)} записей из {total} URL",
                )

        return all_items, results

    async def _process_one(
        self,
        raw_url: str,
        client: HttpClient,
        ozon_parser: OzonParser,
        wb_parser: WBParser,
    ) -> list[QAItem]:
        """Обработать один URL."""
        parsed = await self._safe_parse(raw_url, client)
        if parsed is None:
            raise ValueError(f"Не распознан URL маркетплейса: {raw_url}")

        if parsed.marketplace == "ozon":
            # Имя товара
            meta = await ozon_parser.fetch_product_meta(parsed.product_id)
            product = Product(
                marketplace="ozon",
                product_id=parsed.product_id,
                name=meta.get("name", ""),
                url=parsed.canonical_url,
            )
            return await ozon_parser.fetch_questions(product)

        if parsed.marketplace == "wb":
            meta = await wb_parser.fetch_product_meta(parsed.product_id)
            product = Product(
                marketplace="wb",
                product_id=parsed.product_id,
                name=meta.get("name", ""),
                url=parsed.canonical_url,
                extra={"imt_id": parsed.imt_id or meta.get("imt_id", "")},
            )
            return await wb_parser.fetch_questions(
                product, imt_id=product.extra.get("imt_id")
            )

        return []

    async def _safe_parse(self, raw_url: str, client: HttpClient):
        """
        Пытается распарсить URL. Если это короткая ссылка Ozon — резолвит её.
        """
        # быстрый путь: уже канонический URL
        parsed = parse_url(raw_url)
        if parsed:
            return parsed

        # медленный путь: резолвим короткую ссылку
        if detect_marketplace(raw_url) == "ozon" and is_ozon_short(raw_url):
            try:
                final = await client.resolve_url(raw_url)
                resolved = parse_ozon_canonical(final)
                if resolved:
                    return resolved
            except Exception:
                pass

        return None
