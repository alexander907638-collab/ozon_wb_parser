"""
Парсер Q&A для Wildberries.

Стратегия:
1. Если в URL передан imtId — используем его. Иначе получаем через card.wb.ru.
2. Запрос страницы https://www.wildberries.ru/catalog/{nmId}/questions?imtId={imtId}
3. Ищем в HTML встроенный JSON:
   - <script id="__NEXT_DATA__" type="application/json">{...}</script>
   - window.__INITIAL_STATE__ = {...};
   - <script id="__NUXT_DATA__"...> (если WB вдруг переехал на Nuxt)
4. Из распарсенного JSON достаём массив вопросов рекурсивно (поле "questions").
5. Fallback: BeautifulSoup-стиль обход HTML по семантическим маркерам.

ВАЖНО: WB не имеет публичного REST-API для вопросов; на странице есть SSR-блок
с встроенным JSON-стейтом (типичная Next.js практика). Если структура изменилась,
включи debug-режим — парсер сохранит сырой HTML.
"""
from __future__ import annotations

import json
import re
from typing import Any

from ..common.http import HttpClient, HttpError
from ..common.types import Product, QAItem, RateLimiter


CARD_API = "https://card.wb.ru/cards/v2/detail"


def _coerce_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (str, int, float)):
        return str(value)
    return ""


class WBParser:
    """Парсер Q&A одного товара WB."""

    def __init__(self, client: HttpClient, limiter: RateLimiter):
        self.client = client
        self.limiter = limiter

    async def fetch_imt_id(self, nm_id: str) -> str:
        """Получить imt_id (root) по nmId через card.wb.ru."""
        await self.limiter.wait()
        params = {
            "appType": "1",
            "curr": "rub",
            "dest": "-1257786",  # Москва — стабильный регион
            "nm": nm_id,
        }
        try:
            data = await self.client.get_json(CARD_API, params=params)
        except HttpError:
            return ""
        products = (data.get("data") or {}).get("products", [])
        if not products:
            return ""
        imt = products[0].get("root") or products[0].get("imt_id")
        return _coerce_str(imt)

    async def fetch_product_meta(self, nm_id: str) -> dict[str, Any]:
        """Имя/бренд товара через card.wb.ru."""
        await self.limiter.wait()
        params = {
            "appType": "1",
            "curr": "rub",
            "dest": "-1257786",
            "nm": nm_id,
        }
        try:
            data = await self.client.get_json(CARD_API, params=params)
        except HttpError:
            return {}
        products = (data.get("data") or {}).get("products", [])
        if not products:
            return {}
        p = products[0]
        return {
            "name": _coerce_str(p.get("name")),
            "brand": _coerce_str(p.get("brand")),
            "imt_id": _coerce_str(p.get("root") or p.get("imt_id")),
        }

    async def fetch_questions(
        self, product: Product, imt_id: str | None = None
    ) -> list[QAItem]:
        """
        Получить все вопросы по товару WB.
        Если imt_id не дан — добываем через card.wb.ru.
        """
        if not imt_id:
            imt_id = product.extra.get("imt_id") or ""
        if not imt_id:
            imt_id = await self.fetch_imt_id(product.product_id)
        if not imt_id:
            print(f"[wb] не удалось получить imt_id для {product.product_id}")
            return []

        await self.limiter.wait()
        url = (
            f"https://www.wildberries.ru/catalog/{product.product_id}"
            f"/questions?imtId={imt_id}"
        )
        try:
            _, html = await self.client.get_text(url)
        except HttpError as e:
            print(f"[wb] не удалось получить страницу вопросов {product.product_id}: {e}")
            return []

        # Стратегия 1: __NEXT_DATA__
        items = self._extract_from_next_data(html, product)
        if items:
            return items

        # Стратегия 2: __INITIAL_STATE__ / window.* присвоения
        items = self._extract_from_initial_state(html, product)
        if items:
            return items

        # Стратегия 3: HTML-парсинг по семантическим маркерам
        return self._extract_from_html_markup(html, product)

    # ---------- Стратегия 1: __NEXT_DATA__ ----------

    def _extract_from_next_data(
        self, html: str, product: Product
    ) -> list[QAItem]:
        m = re.search(
            r'<script\s+id="__NEXT_DATA__"[^>]*>(.+?)</script>',
            html,
            re.DOTALL,
        )
        if not m:
            return []
        try:
            data = json.loads(m.group(1))
        except json.JSONDecodeError:
            return []
        return self._extract_questions_from_anywhere(data, product)

    # ---------- Стратегия 2: window.__INITIAL_STATE__ ----------

    def _extract_from_initial_state(
        self, html: str, product: Product
    ) -> list[QAItem]:
        # Возможные варианты: window.__INITIAL_STATE__, window.__PRELOADED_STATE__
        for var_name in ("__INITIAL_STATE__", "__PRELOADED_STATE__", "__APP_DATA__"):
            m = re.search(
                rf'window\.{var_name}\s*=\s*(\{{.+?\}})\s*[;<]',
                html,
                re.DOTALL,
            )
            if not m:
                continue
            try:
                data = json.loads(m.group(1))
            except json.JSONDecodeError:
                continue
            items = self._extract_questions_from_anywhere(data, product)
            if items:
                return items
        return []

    # ---------- Универсальный поиск массива questions в произвольном JSON ----------

    def _extract_questions_from_anywhere(
        self, data: Any, product: Product
    ) -> list[QAItem]:
        """
        Рекурсивный поиск массива questions внутри произвольной JSON-структуры.
        Возвращает все найденные вопросы (без дубликатов по id).
        """
        seen_ids: set[str] = set()
        items: list[QAItem] = []

        def visit(node: Any) -> None:
            if isinstance(node, dict):
                # Ключи, которые могут содержать массив вопросов
                for key in ("questions", "items", "list"):
                    val = node.get(key)
                    if isinstance(val, list) and val and isinstance(val[0], dict):
                        # Проверим, что это похоже на вопросы (есть text + либо answer, либо id)
                        sample = val[0]
                        if self._looks_like_question(sample):
                            for q in val:
                                self._consume_question(q, product, items, seen_ids)
                # Рекурсивно обходим всё остальное
                for v in node.values():
                    visit(v)
            elif isinstance(node, list):
                for el in node:
                    visit(el)

        visit(data)
        return items

    @staticmethod
    def _looks_like_question(node: dict) -> bool:
        """Эвристика: похож ли dict на вопрос."""
        if not isinstance(node, dict):
            return False
        keys = set(node.keys())
        # Обязательно должно быть text или question
        if not (keys & {"text", "question", "questionText"}):
            return False
        # И что-то идентифицирующее
        if not (keys & {"id", "questionId", "uuid"}):
            return False
        return True

    def _consume_question(
        self,
        q: dict,
        product: Product,
        items: list[QAItem],
        seen_ids: set[str],
    ) -> None:
        q_id = _coerce_str(q.get("id") or q.get("questionId") or q.get("uuid"))
        if not q_id or q_id in seen_ids:
            return
        seen_ids.add(q_id)

        q_text = _coerce_str(
            q.get("text") or q.get("question") or q.get("questionText")
        )
        q_author = (
            _coerce_str(q.get("userName"))
            or _coerce_str(q.get("authorName"))
            or _coerce_str((q.get("author") or {}).get("name") if isinstance(q.get("author"), dict) else "")
        )
        q_date = _coerce_str(
            q.get("createdDate") or q.get("createdAt") or q.get("date")
        )

        # Ответ (один)
        ans = q.get("answer")
        ans_text = ""
        ans_author = ""
        ans_date = ""
        if isinstance(ans, dict):
            ans_text = _coerce_str(ans.get("text"))
            ans_author = _coerce_str(
                ans.get("userName") or ans.get("authorName")
            )
            ans_date = _coerce_str(
                ans.get("createDate") or ans.get("createdDate") or ans.get("date")
            )

        items.append(QAItem(
            marketplace="wb",
            product_id=product.product_id,
            product_name=product.name,
            product_url=product.url,
            item_type="question",
            item_id=q_id,
            text=q_text,
            author=q_author,
            created_at=q_date,
            answer_text=ans_text,
            answer_author=ans_author,
            answer_at=ans_date,
        ))

    # ---------- Стратегия 3: HTML markup fallback ----------

    def _extract_from_html_markup(
        self, html: str, product: Product
    ) -> list[QAItem]:
        """
        Если ни одного встроенного JSON нет — пытаемся вытащить из HTML.
        WB обычно использует data-feedback-id или подобные семантические атрибуты.
        Это последняя линия защиты — может быть неточной.
        """
        items: list[QAItem] = []

        # Попробуем data-question-id, data-feedback-id и аналоги
        patterns = [
            re.compile(r'data-question-id="([^"]+)"', re.IGNORECASE),
            re.compile(r'data-feedback-id="([^"]+)"', re.IGNORECASE),
            # WB любит "ng-question-..." или "j-question-card__id"
            re.compile(r'data-id="([^"]+)"[^>]*class="[^"]*question[^"]*"', re.IGNORECASE),
        ]
        all_positions: list[tuple[int, str]] = []
        for pat in patterns:
            for m in pat.finditer(html):
                all_positions.append((m.start(), m.group(1)))

        if not all_positions:
            return items

        # Сортируем по позиции и удаляем дубли по id
        all_positions.sort()
        seen = set()
        positions: list[tuple[int, str]] = []
        for pos, qid in all_positions:
            if qid in seen:
                continue
            seen.add(qid)
            positions.append((pos, qid))

        positions.append((len(html), ""))

        for i in range(len(positions) - 1):
            start, q_id = positions[i]
            end = positions[i + 1][0]
            chunk = html[start:end]
            text = self._strip_tags(chunk)
            if not text:
                continue
            items.append(QAItem(
                marketplace="wb",
                product_id=product.product_id,
                product_name=product.name,
                product_url=product.url,
                item_type="question",
                item_id=q_id,
                text=text[:1000],
            ))
        return items

    @staticmethod
    def _strip_tags(html_chunk: str) -> str:
        """Грубая очистка HTML-тегов с сохранением структуры через переносы."""
        clean = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", html_chunk, flags=re.DOTALL)
        text = re.sub(r"<[^>]+>", " ", clean)
        text = re.sub(r"\s+", " ", text).strip()
        return text
