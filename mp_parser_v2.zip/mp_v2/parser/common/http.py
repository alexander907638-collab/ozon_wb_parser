"""Универсальный HTTP-клиент с retry, прокси и debug-режимом."""
from __future__ import annotations

import asyncio
import hashlib
import random
from pathlib import Path
from typing import Any

import aiohttp
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)


# UA мобильного приложения Ozon — критично для api.ozon.ru/composer-api.bx
OZON_MOBILE_UA = (
    "ozonapp_android/17.40.0+2138 "
    "(Linux; Android 12; SM-G991B; com.ozon.app.android)"
)

# Браузерные UA — для wildberries.ru и fallback HTML парсинга Ozon
DESKTOP_UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
]


class HttpError(Exception):
    """Ошибка HTTP-запроса (после исчерпания retry)."""


def _safe_filename(s: str) -> str:
    """Делаем из URL/произвольной строки безопасное имя файла."""
    h = hashlib.md5(s.encode()).hexdigest()[:8]
    safe = "".join(c if c.isalnum() else "_" for c in s)[:60]
    return f"{safe}_{h}"


class HttpClient:
    """
    Тонкая обёртка над aiohttp. Поддерживает:
    - прокси (HTTP/SOCKS через сторонний transport)
    - retry с exponential backoff
    - кастомные заголовки (через __init__ или per-request)
    - debug-дамп всех ответов в файл
    """

    def __init__(
        self,
        proxy: str | None = None,
        timeout: int = 30,
        default_headers: dict[str, str] | None = None,
        debug_dir: Path | None = None,
    ):
        self.proxy = proxy or None
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.default_headers = default_headers or {
            "User-Agent": random.choice(DESKTOP_UAS),
            "Accept": "*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
        }
        self.debug_dir = debug_dir
        if self.debug_dir:
            self.debug_dir.mkdir(parents=True, exist_ok=True)
        self._session: aiohttp.ClientSession | None = None

    async def __aenter__(self) -> "HttpClient":
        self._session = aiohttp.ClientSession(
            timeout=self.timeout,
            headers=self.default_headers,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._session:
            await self._session.close()

    def _save_debug(self, url: str, content: bytes, suffix: str = ".txt") -> None:
        if not self.debug_dir:
            return
        try:
            name = _safe_filename(url) + suffix
            (self.debug_dir / name).write_bytes(content)
        except Exception:
            pass  # debug не должен ломать основной поток

    @retry(
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
    )
    async def get_text(
        self,
        url: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        allow_redirects: bool = True,
    ) -> tuple[str, str]:
        """
        GET с возвратом (final_url, body_text).
        final_url учитывает все редиректы — нужно для коротких ссылок.
        """
        if not self._session:
            raise RuntimeError("Используй HttpClient как async context manager")

        async with self._session.get(
            url,
            params=params,
            headers=headers,
            proxy=self.proxy,
            allow_redirects=allow_redirects,
        ) as resp:
            body = await resp.read()
            final_url = str(resp.url)
            self._save_debug(url, body)

            if resp.status == 403:
                raise HttpError(f"403 Forbidden: {url} (прокси/CF/host-allowlist?)")
            if resp.status == 429:
                raise HttpError(f"429 Rate limit: {url}")
            if resp.status >= 400:
                raise HttpError(f"HTTP {resp.status}: {url} body={body[:200]!r}")

            try:
                text = body.decode("utf-8")
            except UnicodeDecodeError:
                text = body.decode("utf-8", errors="replace")
            return final_url, text

    async def get_json(
        self,
        url: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """GET с парсингом JSON-ответа."""
        import json as _json
        _, text = await self.get_text(url, params=params, headers=headers)
        try:
            return _json.loads(text)
        except _json.JSONDecodeError as e:
            raise HttpError(
                f"Не JSON ответ от {url}: {text[:200]!r}"
            ) from e

    async def resolve_url(self, url: str) -> str:
        """
        Развернуть редиректы (короткая ссылка → канонический URL).
        Возвращает финальный URL после всех 30x.
        """
        try:
            final_url, _ = await self.get_text(url, allow_redirects=True)
            return final_url
        except HttpError:
            # если не получилось получить контент, попробуем хотя бы HEAD
            if not self._session:
                return url
            try:
                async with self._session.head(
                    url,
                    proxy=self.proxy,
                    allow_redirects=True,
                ) as resp:
                    return str(resp.url)
            except Exception:
                return url
