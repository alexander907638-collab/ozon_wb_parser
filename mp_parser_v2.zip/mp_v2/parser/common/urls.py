"""
Распознавание URL маркетплейсов.

Поддерживаемые форматы:

Ozon:
- https://ozon.ru/t/Qi5LlJq                               (короткая, нужен резолв)
- https://www.ozon.ru/product/название-3086671642/        (канонический)
- https://www.ozon.ru/product/3086671642/                 (без slug)
- ...любые query params (?from=share, &tab=questions и т.д.) — игнорируем

WB:
- https://www.wildberries.ru/catalog/876372959/detail.aspx
- https://www.wildberries.ru/catalog/876372959/questions
- https://wildberries.ru/catalog/876372959/...
- ?imtId=870296272 — если есть, используем; если нет — добываем через card.wb.ru
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import urlparse


@dataclass
class ParsedURL:
    """Результат разбора входящей ссылки."""
    marketplace: str       # "ozon" | "wb"
    product_id: str        # Ozon: SKU; WB: nmId
    canonical_url: str     # URL карточки без query params
    imt_id: str = ""       # WB-специфично; "" если не удалось извлечь из URL


# --- Ozon ---

OZON_SHORT_HOSTS = {"ozon.ru", "www.ozon.ru"}
# короткая ссылка — это путь /t/XXXXX (буквы+цифры, без слэшей внутри)
_OZON_SHORT_RE = re.compile(r"^/t/[A-Za-z0-9]+/?$")
# канонический товар: /product/<slug>-<id>/  ИЛИ  /product/<id>/
_OZON_PRODUCT_RE = re.compile(r"^/product/(?:[^/]+-)?(\d+)/?$")


def is_ozon_short(url: str) -> bool:
    """Это короткая ссылка Ozon (требует резолва)?"""
    try:
        u = urlparse(url)
    except ValueError:
        return False
    if u.netloc.lower() not in OZON_SHORT_HOSTS:
        return False
    return bool(_OZON_SHORT_RE.match(u.path))


def parse_ozon_canonical(url: str) -> ParsedURL | None:
    """
    Разбор канонической ссылки Ozon на товар.
    Возвращает None, если URL не похож на товар.
    """
    try:
        u = urlparse(url)
    except ValueError:
        return None
    if "ozon.ru" not in u.netloc.lower():
        return None
    m = _OZON_PRODUCT_RE.match(u.path)
    if not m:
        return None
    product_id = m.group(1)
    canonical = f"https://www.ozon.ru/product/{product_id}/"
    return ParsedURL(
        marketplace="ozon",
        product_id=product_id,
        canonical_url=canonical,
    )


# --- WB ---

# /catalog/<nmId>/...  или  /product/<nmId>  (бывает реже)
_WB_NMID_RE = re.compile(r"/catalog/(\d+)(?:/|$)")
_WB_IMT_RE = re.compile(r"[?&]imtId=(\d+)")


def parse_wb(url: str) -> ParsedURL | None:
    """Разбор ссылки на товар WB."""
    try:
        u = urlparse(url)
    except ValueError:
        return None
    if "wildberries.ru" not in u.netloc.lower():
        return None
    m = _WB_NMID_RE.search(u.path)
    if not m:
        return None
    nm_id = m.group(1)

    # imtId может быть в query
    imt_id = ""
    imt_m = _WB_IMT_RE.search(url)
    if imt_m:
        imt_id = imt_m.group(1)

    canonical = f"https://www.wildberries.ru/catalog/{nm_id}/detail.aspx"
    return ParsedURL(
        marketplace="wb",
        product_id=nm_id,
        canonical_url=canonical,
        imt_id=imt_id,
    )


# --- Универсальная точка входа ---

def detect_marketplace(url: str) -> str | None:
    """Угадать площадку по домену. None — не маркетплейс."""
    try:
        host = urlparse(url).netloc.lower()
    except ValueError:
        return None
    if "ozon.ru" in host:
        return "ozon"
    if "wildberries.ru" in host:
        return "wb"
    return None


def parse_url(url: str) -> ParsedURL | None:
    """
    Разобрать ссылку без резолва редиректов.
    Возвращает None, если URL не распознан (или это короткая ссылка Ozon —
    тогда сначала надо вызвать HttpClient.resolve_url).
    """
    mp = detect_marketplace(url)
    if mp == "ozon":
        if is_ozon_short(url):
            return None  # требуется резолв
        return parse_ozon_canonical(url)
    if mp == "wb":
        return parse_wb(url)
    return None


def split_lines(text: str) -> list[str]:
    """
    Разобрать пользовательский ввод (textarea/файл) в список URL.
    Удаляет пустые строки и пробелы. Поддерживает разделители: \\n, \\r, ;
    """
    if not text:
        return []
    # сначала по строкам, потом каждую — по ;
    raw = []
    for line in text.replace("\r", "\n").split("\n"):
        for chunk in line.split(";"):
            s = chunk.strip()
            if s:
                raw.append(s)
    return raw
