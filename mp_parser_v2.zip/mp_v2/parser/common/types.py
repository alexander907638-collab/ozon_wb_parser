"""Общие типы и утилиты сохранения."""
from __future__ import annotations

import asyncio
import csv
import json
import random
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass
class Product:
    """Товар, по которому парсим Q&A."""
    marketplace: str           # "ozon" | "wb"
    product_id: str            # Ozon: SKU/число в slug; WB: nmId
    name: str = ""
    url: str = ""              # канонический URL карточки
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class QAItem:
    """Один вопрос/ответ/отзыв."""
    marketplace: str
    product_id: str
    product_name: str
    product_url: str
    item_type: str             # "question" | "review" | "answer"
    item_id: str
    text: str
    author: str = ""
    rating: int | None = None  # для отзывов
    created_at: str = ""
    answer_text: str = ""      # ответ продавца (если есть, для question/review)
    answer_author: str = ""
    answer_at: str = ""
    parent_id: str = ""        # для вложенных ответов как отдельных записей


class RateLimiter:
    """Глобальный rate-limiter с jitter."""

    def __init__(self, base_delay: float, jitter: float = 0.3):
        self.base_delay = base_delay
        self.jitter = jitter
        self._lock = asyncio.Lock()

    async def wait(self) -> None:
        async with self._lock:
            delay = self.base_delay * (1 + random.uniform(-self.jitter, self.jitter))
            await asyncio.sleep(max(0.1, delay))


def save_to_csv(items: list[QAItem], path: Path) -> None:
    """Сохраняем CSV (с BOM для корректного открытия в Excel)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if not items:
        # пустой файл с заголовками
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(
                f, fieldnames=list(QAItem.__annotations__.keys())
            )
            writer.writeheader()
        return

    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(items[0]).keys()))
        writer.writeheader()
        for item in items:
            writer.writerow(asdict(item))


def save_to_json(items: list[QAItem], path: Path) -> None:
    """Сохраняем JSON с item-словарями."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump([asdict(item) for item in items], f, ensure_ascii=False, indent=2)


def today_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H%M%S")
