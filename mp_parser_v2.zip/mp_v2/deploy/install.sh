#!/usr/bin/env bash
# Деплой mp_parser на голую Ubuntu 24.
#
# Использование (от root):
#   1. Загрузить архив проекта на сервер любым способом (см. README → "Заливка")
#   2. Распаковать в /tmp/mp_v2
#   3. Запустить:
#        cd /tmp/mp_v2 && BASIC_AUTH_USER=admin BASIC_AUTH_PASS='SuperSecret' bash deploy/install.sh
#
# Скрипт идемпотентный — повторный запуск обновит код.

set -euo pipefail

APP_DIR="/opt/mp_parser"
DATA_DIR="/var/lib/mp_parser"
USER="mp_parser"
PYTHON="python3.12"

if [[ $EUID -ne 0 ]]; then
    echo "Запускай от root: sudo bash $0"
    exit 1
fi

echo "==> 1/9. apt update + системные пакеты"
apt-get update -qq
apt-get install -y -qq \
    python3.12 python3.12-venv python3-pip \
    nginx apache2-utils \
    rsync curl

echo "==> 2/9. Системный пользователь $USER"
if ! id "$USER" &>/dev/null; then
    useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin "$USER"
fi

echo "==> 3/9. Директории"
mkdir -p "$APP_DIR" "$DATA_DIR/output"
chown -R "$USER:$USER" "$DATA_DIR"

echo "==> 4/9. Копирование исходников"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
rsync -a --delete \
    --exclude='.venv' --exclude='__pycache__' --exclude='*.pyc' \
    --exclude='output' --exclude='.env' \
    "$SRC_DIR/" "$APP_DIR/"

echo "==> 5/9. .env"
if [[ ! -f "$APP_DIR/.env" ]]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
    chmod 600 "$APP_DIR/.env"
    echo "    создан $APP_DIR/.env — отредактируй HTTP_PROXY если нужен"
else
    echo "    .env уже существует — не трогаю"
fi
sed -i "s|^OUTPUT_DIR=.*|OUTPUT_DIR=$DATA_DIR/output|" "$APP_DIR/.env"

echo "==> 6/9. Python venv + зависимости"
if [[ ! -d "$APP_DIR/.venv" ]]; then
    $PYTHON -m venv "$APP_DIR/.venv"
fi
"$APP_DIR/.venv/bin/pip" install --upgrade pip --quiet
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt" --quiet
chown -R "$USER:$USER" "$APP_DIR"

echo "==> 7/9. systemd unit"
cp "$APP_DIR/deploy/mp_parser.service" /etc/systemd/system/mp_parser.service
systemctl daemon-reload
systemctl enable mp_parser

echo "==> 8/9. nginx + basic auth"
if [[ ! -f /etc/nginx/.htpasswd ]]; then
    if [[ -z "${BASIC_AUTH_USER:-}" || -z "${BASIC_AUTH_PASS:-}" ]]; then
        echo ""
        echo "    !!! Не задан логин/пароль для basic auth."
        echo "    !!! Запусти повторно с переменными:"
        echo "    !!!   BASIC_AUTH_USER=admin BASIC_AUTH_PASS='SuperSecret123' bash $0"
        exit 1
    fi
    htpasswd -cbB /etc/nginx/.htpasswd "$BASIC_AUTH_USER" "$BASIC_AUTH_PASS"
    echo "    htpasswd создан для пользователя '$BASIC_AUTH_USER'"
else
    echo "    .htpasswd уже существует — не трогаю (изменить: htpasswd -B /etc/nginx/.htpasswd USER)"
fi

cp "$APP_DIR/deploy/nginx.conf" /etc/nginx/sites-available/mp_parser
ln -sf /etc/nginx/sites-available/mp_parser /etc/nginx/sites-enabled/mp_parser
rm -f /etc/nginx/sites-enabled/default
nginx -t

echo "==> 9/9. Запуск сервисов"
systemctl restart mp_parser
systemctl reload nginx || systemctl restart nginx

sleep 2
if systemctl is-active --quiet mp_parser; then
    echo "    mp_parser: OK"
else
    echo "    !!! mp_parser НЕ запустился — смотри: journalctl -u mp_parser -n 50"
    exit 1
fi

IP=$(curl -s --max-time 5 ifconfig.me || echo "<server-ip>")

cat <<EOF

==============================================
 Деплой завершён.
 URL:    http://$IP/
 Логин:  ${BASIC_AUTH_USER:-(уже был)}

 Логи:   journalctl -u mp_parser -f
 .env:   $APP_DIR/.env
 Файлы:  $DATA_DIR/output/
==============================================
EOF
