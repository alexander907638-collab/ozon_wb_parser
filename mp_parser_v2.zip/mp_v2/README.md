# MP Q&A Parser v2

Парсер вопросов и ответов с карточек товаров **Ozon** и **Wildberries** с
веб-интерфейсом. Работает по списку URL (поддерживает короткие ссылки Ozon).

## Что умеет

- Парсит **вопросы покупателей и ответы продавцов** с публичных страниц карточек товаров (без авторизации, без Seller API)
- Принимает **смешанный список Ozon + WB**, площадка определяется автоматически из домена
- Поддерживает **короткие ссылки Ozon** (`ozon.ru/t/Qi5LlJq`) — резолвит редиректы автоматически
- Веб-интерфейс с прогресс-баром (X из Y URL обработано)
- Просмотр результатов прямо в вебе — с фильтрами по типу и поиском
- Скачивание CSV и JSON
- Без Telegram, Docker, Celery — только FastAPI + uvicorn под systemd

## Архитектура

```
[браузер]
    ↓ HTTP basic auth
[nginx :80]
    ↓ proxy_pass
[uvicorn :8765]  ← systemd unit
    ↓
FastAPI app
    ↓
TaskManager (in-memory)
    ↓
ParserPipeline
    ├── OzonParser  → api.ozon.ru/composer-api.bx (mobile UA)
    │                 + HTML fallback /product/{id}/questions/
    └── WBParser    → www.wildberries.ru/catalog/{nm}/questions
                      → JSON в __NEXT_DATA__/__INITIAL_STATE__
                      + HTML markup fallback
```

## Деплой на голую Ubuntu 24

### Шаг 1. Заархивировать локально

На своей машине:

```bash
cd mp_v2/..
zip -r mp_v2.zip mp_v2 -x "*.pyc" "*__pycache__*"
```

### Шаг 2. Залить на файлообменник

Любой из вариантов:

```bash
# Вариант A: 0x0.st (одноразовая ссылка)
curl -F'file=@mp_v2.zip' https://0x0.st

# Вариант B: file.io (одноразовая, авто-удаление после скачивания)
curl -F "file=@mp_v2.zip" https://file.io
# В ответе будет {"link":"https://file.io/XXXXXX"} — копируй link

# Вариант C: transfer.sh (если работает)
curl --upload-file mp_v2.zip https://transfer.sh/mp_v2.zip

# Вариант D: temp.sh
curl -T mp_v2.zip https://temp.sh/mp_v2.zip
```

### Шаг 3. Скачать на сервере и развернуть

На сервере (от root):

```bash
cd /tmp
wget 'СКОПИРОВАННАЯ_ССЫЛКА' -O mp_v2.zip
unzip mp_v2.zip
cd mp_v2

BASIC_AUTH_USER=admin \
BASIC_AUTH_PASS='длинный_надёжный_пароль' \
bash deploy/install.sh
```

Скрипт сам всё сделает: установит python3.12, nginx, htpasswd, создаст
системного пользователя, развернёт venv, настроит systemd и nginx,
запустит сервис.

### Шаг 4. Проверить

```bash
curl -u admin:пароль http://YOUR_SERVER_IP/
# должен вернуть HTML с формой
```

Открыть в браузере: `http://YOUR_SERVER_IP/` → ввести логин/пароль →
вставить пару URL → нажать "Запустить парсинг".

## Использование

### Что вводить в форму

В textarea — ссылки на товары, **по одной на строку**. Можно мешать Ozon и WB:

```
https://ozon.ru/t/Qi5LlJq
https://www.wildberries.ru/catalog/876372959/detail.aspx
https://www.ozon.ru/product/polaris-aerogril-3086671642/
https://wildberries.ru/catalog/12345/feedbacks?imtId=67890
```

Альтернативно — загрузить `.txt` файл со списком (если оба есть, объединяются).

### Что возвращается

- **CSV** (Excel-совместимый, BOM в начале)
- **JSON** (для программной обработки)
- **Report JSON** — статус обработки каждого URL отдельно
- Прямо в вебе — таблица записей с фильтрами по типу (вопрос/ответ/отзыв) и поиском

## Поля в результатах

| Поле | Описание |
|---|---|
| `marketplace` | `ozon` / `wb` |
| `product_id` | Ozon SKU / WB nmId |
| `product_name` | Название товара |
| `product_url` | Канонический URL карточки |
| `item_type` | `question` / `answer` / `review` |
| `item_id` | ID записи на маркетплейсе |
| `text` | Текст вопроса/отзыва |
| `author` | Имя автора |
| `created_at` | Дата создания |
| `answer_text` | Текст ответа продавца (если есть) |
| `answer_author` | Кто ответил (продавец/бренд) |
| `answer_at` | Дата ответа |
| `parent_id` | Для вложенных ответов — id вопроса-родителя |

## Эксплуатация

```bash
# Логи в реальном времени
journalctl -u mp_parser -f

# Перезапуск после правок .env
systemctl restart mp_parser

# Сменить пароль basic auth
htpasswd -B /etc/nginx/.htpasswd admin
systemctl reload nginx

# Обновление кода (заливаем новый zip и повторяем install.sh)
cd /tmp && rm -rf mp_v2 mp_v2.zip
wget 'НОВАЯ_ССЫЛКА' -O mp_v2.zip && unzip mp_v2.zip
cd mp_v2 && bash deploy/install.sh

# Очистка старых результатов
find /var/lib/mp_parser/output -type f -mtime +30 -delete
```

## Если что-то сломалось

### Ozon возвращает пусто или 403

1. Проверить с RU IP (`api.ozon.ru/composer-api.bx` режет иностранные хосты — `Host not in allowlist`)
2. Включить debug в форме → сырой ответ ляжет в `/var/lib/mp_parser/output/debug_<task_id>/`
3. Если структура `widgetStates` поменялась, в `parser/ozon/parser.py` есть константа `QUESTIONS_WIDGET_PATTERNS` — добавить новые имена

### WB возвращает пусто

1. Включить debug → проверить, есть ли `__NEXT_DATA__` в HTML (мог переехать на другой механизм)
2. WB иногда обновляет вёрстку — посмотреть, какой блок содержит JSON со state

### Прокси

Для парсинга НЕ из России — добавь HTTP/SOCKS5 прокси с RU IP в `.env`:
```
HTTP_PROXY=http://user:pass@proxy.example.com:8080
```

## Структура проекта

```
mp_v2/
├── parser/                       # ядро парсинга
│   ├── common/
│   │   ├── http.py               # aiohttp + retry + redirect resolver + debug
│   │   ├── types.py              # Product, QAItem, save_to_csv/json
│   │   └── urls.py               # парсинг URL, определение площадки
│   ├── ozon/parser.py            # composer-api + HTML fallback
│   ├── wb/parser.py              # __NEXT_DATA__ + HTML fallback
│   └── pipeline.py               # оркестратор
├── webapp/
│   ├── main.py                   # FastAPI routes
│   ├── tasks.py                  # TaskManager (in-memory)
│   ├── templates/
│   │   ├── index.html            # форма + список задач
│   │   └── task_detail.html      # детали + просмотр items
│   └── static/style.css
├── deploy/
│   ├── install.sh                # one-shot скрипт
│   ├── mp_parser.service         # systemd
│   └── nginx.conf                # с basic auth
├── requirements.txt
├── .env.example
└── README.md
```

## Технические подробности

### Почему `api.ozon.ru/composer-api.bx`, а не `www.ozon.ru/api/entrypoint-api.bx`?

Это endpoint мобильного приложения Ozon. Он возвращает идентичный по структуре JSON,
но **не защищён Cloudflare**. Подтверждено публичным кейсом
[JTJag/ozon-sellers-parser](https://github.com/JTJag/ozon-sellers-parser): автор спарсил
46 тысяч страниц без капчи и прокси, в 19 потоков. Единственный нюанс — Ozon
проверяет, что IP «российский»: с дата-центров за рубежом возвращает
`Host not in allowlist` (HTTP 403).

### Почему WB через HTML, а не API?

У WB нет публичного REST для вопросов. Документированный
`feedbacks-api.wildberries.ru/api/v1/questions` требует токен **продавца**.
Но вопросы есть на странице `/catalog/{nmId}/questions` без авторизации —
это SSR с встроенным JSON-стейтом (`<script id="__NEXT_DATA__">`),
который и парсим.

### Limitations

- **In-memory задачи**: `systemctl restart mp_parser` теряет running-задачи
  (но файлы CSV/JSON на диске остаются)
- **Один воркер uvicorn**: для шаринга state. Если нужно горизонтально
  масштабировать — нужен Redis/SQLite для TaskManager
- **HTTP без SSL**: basic auth уходит открытым текстом. На проде с реальным
  доменом → `certbot --nginx`
