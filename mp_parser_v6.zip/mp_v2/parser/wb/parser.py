"""
Парсер Q&A для Wildberries через Playwright/Patchright.

Стратегия получения imt_id:
1. Открываем страницу карточки товара /catalog/{nm}/detail.aspx
2. Если страница нормально загрузилась — извлекаем imt_id из DOM/HTML
3. Если на странице блок или imt_id не нашёлся — fallback на card.wb.ru:
   делаем goto на card.wb.ru/cards/v2/detail?nm=... — браузер отдаст
   страницу с pre-форматированным JSON, парсим его

Стратегия получения вопросов:
1. После того как известен imt_id, идём на /catalog/{nm}/questions?imtId=...
2. Дожидаемся появления карточек, скроллим, парсим DOM
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from playwright.async_api import Page, TimeoutError as PWTimeoutError

from ..common.browser import BrowserManager
from ..common.types import Product, QAItem, RateLimiter


logger = logging.getLogger(__name__)


EXTRACT_QUESTIONS_JS = r"""
() => {
    const candidateSelectors = [
        '[data-feedback-id]',
        '[data-id][class*="question"]',
        '.feedback__list .feedback',
        'div.questions__list > *',
        '[class*="question-card"]',
        '[class*="QuestionItem"]',
        '[class*="questions"] > [class*="item"]',
    ];

    let cards = [];
    for (const sel of candidateSelectors) {
        const found = Array.from(document.querySelectorAll(sel));
        if (found.length > 0) { cards = found; break; }
    }

    if (cards.length === 0) {
        const all = Array.from(document.querySelectorAll('main *')).filter(el => {
            const t = (el.innerText || '').toLowerCase();
            return el.children.length > 0
                && t.length > 50
                && t.length < 5000
                && (t.includes('ответ продавца') || t.includes('ответ wildberries')
                    || t.includes('задал вопрос') || t.includes('написал'));
        });
        cards = all.filter(el =>
            !all.some(other => other !== el && other.contains(el))
        );
    }

    if (cards.length === 0) return [];

    const dateRe = /^\d{1,2}\s+[а-яё]+\s+\d{4}$/i;
    const isJunk = t =>
        /^(Лучший ответ|Полезно|Бесполезно)$/i.test(t)
        || /^(Да|Нет)\s*\d*$/i.test(t)
        || /^Ещё (\d+ )?ответ/i.test(t)
        || /^Еще (\d+ )?ответ/i.test(t)
        || /^\d+$/.test(t)
        || t.length < 2;

    function leafTexts(root) {
        const out = [];
        const walker = document.createTreeWalker(
            root, NodeFilter.SHOW_ELEMENT, {
                acceptNode(el) {
                    if (el.children.length === 0) return NodeFilter.FILTER_ACCEPT;
                    const allInline = Array.from(el.children).every(c =>
                        ['SPAN', 'B', 'I', 'EM', 'STRONG', 'BR', 'A'].includes(c.tagName)
                    );
                    return allInline ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                }
            }
        );
        let node;
        while ((node = walker.nextNode())) {
            const t = (node.innerText || '').trim();
            if (t.length > 0 && !isJunk(t)) out.push(t);
        }
        return out;
    }

    const out = [];
    cards.forEach((card, idx) => {
        const id = card.getAttribute('data-feedback-id')
                || card.getAttribute('data-id')
                || card.getAttribute('id')
                || `wb_${idx}`;
        const texts = leafTexts(card);
        if (texts.length === 0) return;

        const date = texts.find(t => dateRe.test(t)) || '';
        const nonDate = texts.filter(t => !dateRe.test(t));
        if (nonDate.length === 0) return;

        const longest = nonDate.reduce((a, b) => a.length >= b.length ? a : b, '');
        const idx2 = nonDate.indexOf(longest);
        const before = nonDate.slice(0, idx2);
        const after = nonDate.slice(idx2 + 1);

        let questionText = longest;
        let questionAuthor = before.find(t => t.length < 40) || '';

        let answerText = '';
        let answerAuthor = '';
        let answerDate = '';
        const answerMarkerIdx = nonDate.findIndex(t =>
            /ответ продавца|ответ wildberries|ответ магазина|ответ бренда/i.test(t)
        );
        if (answerMarkerIdx >= 0) {
            const afterMarker = nonDate.slice(answerMarkerIdx + 1);
            if (afterMarker.length > 0) {
                answerText = afterMarker.reduce((a, b) =>
                    a.length >= b.length ? a : b, '');
                answerAuthor = afterMarker.find(t => t !== answerText && t.length < 50) || '';
            }
        } else if (after.length > 0) {
            const longestAfter = after.reduce((a, b) =>
                a.length >= b.length ? a : b, '');
            if (longestAfter.length > 30) {
                answerText = longestAfter;
                answerAuthor = after.find(t => t !== longestAfter && t.length < 50) || '';
            }
        }
        if (answerText) {
            const ansIdx = nonDate.indexOf(answerText);
            for (let i = ansIdx + 1; i < texts.length; i++) {
                if (dateRe.test(texts[i])) { answerDate = texts[i]; break; }
            }
        }

        out.push({
            id: String(id),
            text: questionText,
            author: questionAuthor,
            date: date,
            answer_text: answerText,
            answer_author: answerAuthor,
            answer_date: answerDate,
        });
    });
    return out;
}
"""


EXTRACT_IMT_FROM_PAGE_JS = r"""
() => {
    let imt = '';
    let name = '';

    const h1 = document.querySelector('h1');
    if (h1) name = (h1.innerText || '').trim().slice(0, 200);

    const elWithRoot = document.querySelector(
        '[data-root-id], [data-imt-id], [data-imt]'
    );
    if (elWithRoot) {
        imt = elWithRoot.getAttribute('data-root-id')
           || elWithRoot.getAttribute('data-imt-id')
           || elWithRoot.getAttribute('data-imt')
           || '';
    }

    if (!imt || !name) {
        const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (const s of ldScripts) {
            try {
                const data = JSON.parse(s.textContent || '{}');
                if (data && typeof data === 'object') {
                    if (!name && data.name) name = String(data.name).slice(0, 200);
                    if (!imt && data.productID) imt = String(data.productID);
                }
            } catch (e) {}
        }
    }

    if (!imt) {
        const html = document.documentElement.outerHTML;
        let m = html.match(/"imtId"\s*:\s*"?(\d+)"?/);
        if (m) imt = m[1];
        if (!imt) {
            m = html.match(/"root"\s*:\s*"?(\d+)"?/);
            if (m) imt = m[1];
        }
        if (!imt) {
            m = html.match(/imtId=(\d+)/);
            if (m) imt = m[1];
        }
    }

    return { imt: String(imt || ''), name: String(name || '') };
}
"""


class WBParser:
    def __init__(self, browser: BrowserManager, limiter: RateLimiter):
        self.browser = browser
        self.limiter = limiter

    async def fetch_questions(
        self, product: Product, imt_id: str | None = None
    ) -> list[QAItem]:
        await self.limiter.wait()
        if not imt_id:
            imt_id = product.extra.get("imt_id") or ""

        async with self.browser.page_slot() as page:
            try:
                # ШАГ 1: страница товара
                if not imt_id or not product.name:
                    pdp_url = (
                        f"https://www.wildberries.ru/catalog/"
                        f"{product.product_id}/detail.aspx"
                    )
                    try:
                        await page.goto(
                            pdp_url,
                            wait_until="domcontentloaded",
                            timeout=45_000,
                        )
                        await page.wait_for_timeout(2_500)

                        if await self._is_blocked(page):
                            logger.warning(
                                "[wb %s] блок на странице товара",
                                product.product_id,
                            )
                            await self.browser._dump_debug(
                                page, f"wb_blocked_pdp_{product.product_id}"
                            )
                        else:
                            try:
                                info = await page.evaluate(
                                    EXTRACT_IMT_FROM_PAGE_JS
                                )
                                if info:
                                    if not imt_id and info.get("imt"):
                                        imt_id = info["imt"]
                                        logger.info(
                                            "[wb %s] imt_id со страницы товара: %s",
                                            product.product_id, imt_id,
                                        )
                                    if not product.name and info.get("name"):
                                        product.name = info["name"]
                            except Exception as e:
                                logger.warning(
                                    "[wb %s] extract imt из PDP: %s",
                                    product.product_id, e,
                                )
                    except PWTimeoutError:
                        logger.warning(
                            "[wb %s] таймаут страницы товара",
                            product.product_id,
                        )

                # ШАГ 1b (fallback): card.wb.ru через отдельный goto.
                # Ходим на новую URL страницей-сырьём — браузер сам форматирует
                # JSON в pre-блоке, мы парсим innerText.
                if not imt_id:
                    api_url = (
                        f"https://card.wb.ru/cards/v2/detail"
                        f"?appType=1&curr=rub&dest=-1257786&nm={product.product_id}"
                    )
                    try:
                        await page.goto(
                            api_url,
                            wait_until="domcontentloaded",
                            timeout=20_000,
                        )
                        body_text = await page.evaluate(
                            "() => document.body.innerText"
                        )
                        try:
                            data = json.loads(body_text)
                            products = (data.get("data") or {}).get("products", [])
                            if products:
                                p0 = products[0]
                                imt_id = str(
                                    p0.get("root") or p0.get("imt_id") or ""
                                )
                                if not product.name:
                                    product.name = str(p0.get("name") or "")
                                if imt_id:
                                    logger.info(
                                        "[wb %s] imt_id через card.wb.ru: %s",
                                        product.product_id, imt_id,
                                    )
                        except (json.JSONDecodeError, ValueError) as e:
                            logger.warning(
                                "[wb %s] card.wb.ru вернул не JSON: %s",
                                product.product_id, e,
                            )
                    except Exception as e:
                        logger.warning(
                            "[wb %s] card.wb.ru fallback упал: %s",
                            product.product_id, e,
                        )

                if not imt_id:
                    logger.warning(
                        "[wb %s] не получили imt_id ни одним способом",
                        product.product_id,
                    )
                    await self.browser._dump_debug(
                        page, f"wb_no_imt_{product.product_id}"
                    )
                    return []

                # ШАГ 2: страница вопросов
                url = (
                    f"https://www.wildberries.ru/catalog/{product.product_id}"
                    f"/questions?imtId={imt_id}"
                )
                return await self._scrape(page, url, product)
            except Exception as e:
                logger.warning("[wb %s] %s", product.product_id, e)
                return []

    async def _is_blocked(self, page: Page) -> bool:
        try:
            title = await page.title()
        except Exception:
            return False
        if not title:
            return False
        bad = ("ограничен", "доступ запрещен", "access denied", "blocked")
        return any(b in title.lower() for b in bad)

    async def _scrape(
        self, page: Page, url: str, product: Product
    ) -> list[QAItem]:
        await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
        await page.wait_for_timeout(2_500)

        if await self._is_blocked(page):
            logger.warning("[wb %s] страница блокировки", product.product_id)
            await self.browser._dump_debug(
                page, f"wb_blocked_{product.product_id}"
            )
            return []

        prev = -1
        stable = 0
        for _ in range(30):
            try:
                count = await page.evaluate(
                    "() => document.querySelectorAll("
                    "'[data-feedback-id], [data-id][class*=\"question\"], "
                    ".feedback__list .feedback, [class*=\"question-card\"], "
                    "[class*=\"QuestionItem\"]'"
                    ").length"
                )
            except Exception:
                break

            if count == prev:
                stable += 1
                if stable >= 3:
                    break
            else:
                stable = 0
                prev = count

            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await page.wait_for_timeout(700)

            for sel in [
                'button:has-text("Показать ещё")',
                'button:has-text("Показать еще")',
                'button:has-text("Загрузить ещё")',
                'div[role="button"]:has-text("Показать ещё")',
            ]:
                try:
                    btn = page.locator(sel).first
                    if await btn.is_visible(timeout=300):
                        await btn.click(timeout=1_500)
                        await page.wait_for_timeout(800)
                        break
                except Exception:
                    continue

        try:
            raw = await page.evaluate(EXTRACT_QUESTIONS_JS)
        except Exception as e:
            logger.warning("[wb %s] evaluate %s", product.product_id, e)
            return []

        if not raw:
            await self.browser._dump_debug(
                page, f"wb_empty_{product.product_id}"
            )

        items = self._convert(raw or [], product)
        logger.info(
            "[wb %s] извлечено: %d записей", product.product_id, len(items)
        )
        return items

    def _convert(
        self, raw: list[dict[str, Any]], product: Product
    ) -> list[QAItem]:
        items: list[QAItem] = []
        seen = set()
        for q in raw:
            qid = str(q.get("id") or "")
            if not qid or qid in seen:
                continue
            seen.add(qid)
            items.append(QAItem(
                marketplace="wb",
                product_id=product.product_id,
                product_name=product.name,
                product_url=product.url,
                item_type="question",
                item_id=qid,
                text=q.get("text") or "",
                author=q.get("author") or "",
                created_at=q.get("date") or "",
                answer_text=q.get("answer_text") or "",
                answer_author=q.get("answer_author") or "",
                answer_at=q.get("answer_date") or "",
            ))
        return items
