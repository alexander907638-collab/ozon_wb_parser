# MP Q&A Parser v2 — Playwright Edition

Парсер вопросов и ответов с карточек товаров **Ozon** и **Wildberries** через
**headless Chromium (Playwright)**. Веб-интерфейс. Работает по списку URL
(поддерживает короткие ссылки Ozon).

## Зачем Playwright

И Ozon, и Wildberries отдают на страницах вопросов **пустые SPA-каркасы**
для клиентов без правильного набора куков. Чистый HTTP-парсинг даёт 0 записей.
Playwright открывает страницу как настоящий браузер, JS отрабатывает,
вопросы появляются в DOM — и оттуда мы их забираем.

Цена: ~300 МБ места на Chromium и 2-5 секунд на товар (вместо <1 сек у HTTP).

## Что умеет

- Парсит вопросы покупателей и ответы продавцов с **публичных** страниц карточек товаров (без авторизации, без Seller API)
- Принимает смешанный список Ozon + WB, площадка определяется автоматически из домена
- Поддерживает короткие ссылки Ozon (`ozon.ru/t/...`) — резолвит редиректы автоматически
- Веб-интерфейс с прогресс-баром
- Просмотр результатов прямо в вебе — с фильтрами по типу и поиском
- Скачивание CSV и JSON
- **Куки и сессионное состояние Chromium сохраняются между прогонами** — чем больше парсишь, тем меньше шанс капчи

## Архитектура

```
[браузер]
    ↓ HTTP basic auth
[nginx :80]
    ↓ proxy_pass
[uvicorn :8765]  ← systemd unit
    ↓
FastAPI app
    ↓
TaskManager (in-memory)
    ↓
ParserPipeline
    ↓
BrowserManager (один shared Chromium)
    ├── OzonParser → goto /product/{id}/questions/ → load all → JS-extract
    └── WBParser   → goto /catalog/{nm}/questions  → load all → JS-extract
```

## Системные требования

- **Ubuntu 24.04** (для других дистрибутивов работает, но `install.sh` не проверял)
- **2+ GB RAM** (Chromium прожорлив; рекомендую 4 GB если будешь парсить много)
- **5+ GB свободного места** (Chromium + системные зависимости + venv ≈ 1.5 GB)

## Деплой

### Шаг 1. Залить исходники на сервер любым способом

git, zip+wget, scp — что удобнее. Главное — оказаться в папке с `parser/`,
`webapp/`, `deploy/` и т.д.

### Шаг 2. Запустить установщик

```bash
cd /tmp/mp_v2  # или где у тебя лежат исходники
BASIC_AUTH_USER=admin \
BASIC_AUTH_PASS='длинный_надёжный_пароль' \
bash deploy/install.sh
```

Скрипт:
1. Поставит python3.12, nginx, htpasswd
2. Создаст системного пользователя `mp_parser`
3. Развернёт venv в `/opt/mp_parser/.venv`
4. **Поставит Chromium** + системные библиотеки (~5-10 минут)
5. Настроит systemd + nginx с basic auth
6. Запустит сервис

После этого: `http://YOUR_SERVER_IP/` → форма парсера.

### Обновление (повторный прогон install.sh)

```bash
cd /tmp/mp_v2_новая_версия
bash deploy/install.sh
```

`.env` и `browser_state.json` сохраняются. Куки не теряются.

## Использование

В textarea вставь ссылки на товары, по одной на строку. Можно мешать Ozon и WB:

```
https://ozon.ru/t/Qi5LlJq
https://www.wildberries.ru/catalog/876372959/detail.aspx
https://www.ozon.ru/product/3086671642/
```

Альтернативно — загрузить `.txt` файл со списком (если оба есть, объединяются).

Жми «Запустить парсинг». Откроется страница задачи с прогрессом X/Y.
Когда статус сменится на «Готово» — увидишь записи прямо в браузере + ссылки на CSV/JSON.

## Поля в результатах

| Поле | Описание |
|---|---|
| `marketplace` | `ozon` / `wb` |
| `product_id` | Ozon SKU / WB nmId |
| `product_name` | Название товара |
| `product_url` | Канонический URL карточки |
| `item_type` | `question` / `answer` |
| `item_id` | ID записи на маркетплейсе |
| `text` | Текст вопроса |
| `author` | Имя автора |
| `created_at` | Дата создания |
| `answer_text` | Текст ответа продавца (если есть) |
| `answer_author` | Кто ответил |
| `answer_at` | Дата ответа |
| `parent_id` | Для дополнительных ответов — id родительского вопроса |

## Эксплуатация

```bash
# логи в реальном времени
journalctl -u mp_parser -f

# перезапуск после правок .env
systemctl restart mp_parser

# сменить пароль basic auth
htpasswd -B /etc/nginx/.htpasswd admin
systemctl reload nginx

# принудительно сбросить накопленные куки (если что-то пошло не так)
rm /var/lib/mp_parser/browser_state.json
systemctl restart mp_parser

# чистка старых результатов
find /var/lib/mp_parser/output -type f -mtime +30 -delete
```

## Настройки в `.env`

```bash
# Сколько страниц одновременно. Главный фактор расхода RAM.
# 1 — медленно, но безопасно (200-400 MB)
# 2 — умеренно (по умолчанию)
# 4+ — быстро, но нужно 4+ GB RAM
MAX_CONCURRENT_PAGES=2

# Задержки между запросами по площадкам — против капчи
OZON_DELAY=2.0
WB_DELAY=1.0

# Headless. На сервере всегда 1.
HEADLESS=1
```

## Если что-то сломалось

### Парсер возвращает 0 записей у всех URL

Скорее всего, накопились «плохие» куки или Ozon выкатил капчу.

```bash
rm /var/lib/mp_parser/browser_state.json
systemctl restart mp_parser
```

При следующем прогоне браузер сделает прогрев (зайдёт на главные страницы),
получит свежие куки.

### `mp_parser` не запускается

```bash
journalctl -u mp_parser -n 50 --no-pager
```

Типичные проблемы:
- **`playwright._impl._api_types.Error: Executable doesn't exist`** — Chromium не установлен. Запусти:
  ```bash
  sudo -u mp_parser PLAYWRIGHT_BROWSERS_PATH=/opt/mp_parser/.playwright_browsers \
    /opt/mp_parser/.venv/bin/playwright install chromium
  ```
- **Out of memory** — снизь `MAX_CONCURRENT_PAGES=1` в `.env`.

### Парсер очень медленный

Это нормально для Playwright: 3-7 секунд на товар. Если медленнее 10 сек — проверь:
```bash
# нагрузка
top
# свободное место
df -h
# сеть
curl -w "%{time_total}\n" -o /dev/null -s https://www.ozon.ru/
```

## Limitations

- **In-memory задачи**: `systemctl restart mp_parser` теряет running-задачи (но файлы CSV/JSON на диске остаются)
- **Один воркер uvicorn**: один shared Chromium на всё приложение. Не масштабируется горизонтально.
- **HTTP без SSL**: basic auth уходит открытым текстом. На проде с реальным доменом → `certbot --nginx`

## Структура проекта

```
mp_v2/
├── parser/
│   ├── common/
│   │   ├── browser.py            # BrowserManager (Playwright singleton)
│   │   ├── types.py              # Product, QAItem
│   │   └── urls.py               # парсинг URL
│   ├── ozon/parser.py            # Playwright + JS-extractor
│   ├── wb/parser.py              # Playwright + JS-extractor
│   └── pipeline.py               # оркестратор
├── webapp/
│   ├── main.py                   # FastAPI + lifespan для браузера
│   ├── tasks.py                  # TaskManager
│   ├── templates/
│   └── static/
├── deploy/
│   ├── install.sh                # one-shot скрипт
│   ├── mp_parser.service
│   └── nginx.conf
├── requirements.txt
├── .env.example
└── README.md
```
