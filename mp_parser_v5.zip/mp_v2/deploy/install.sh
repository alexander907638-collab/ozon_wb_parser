#!/usr/bin/env bash
# Деплой mp_parser (Playwright + stealth) на голую Ubuntu 24.
#
# Использование (от root):
#   cd <папка_с_исходниками>
#   BASIC_AUTH_USER=admin BASIC_AUTH_PASS='SuperSecret' bash deploy/install.sh
#
# Идемпотентно — повторный запуск обновит код, зависимости и storage_state не теряет.

set -euo pipefail

APP_DIR="/opt/mp_parser"
DATA_DIR="/var/lib/mp_parser"
USER="mp_parser"
PYTHON="python3.12"
PLAYWRIGHT_BROWSERS_PATH="$APP_DIR/.playwright_browsers"

if [[ $EUID -ne 0 ]]; then
    echo "Запускай от root: sudo bash $0"
    exit 1
fi

echo "==> 1/10. apt update + системные пакеты"
apt-get update -qq
apt-get install -y -qq \
    python3.12 python3.12-venv python3-pip \
    nginx apache2-utils \
    rsync curl wget unzip ca-certificates

echo "==> 2/10. Системный пользователь $USER"
if ! id "$USER" &>/dev/null; then
    useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin "$USER"
fi

echo "==> 3/10. Директории"
mkdir -p "$APP_DIR" "$DATA_DIR/output" "$DATA_DIR/output/debug" "$PLAYWRIGHT_BROWSERS_PATH"
chown -R "$USER:$USER" "$DATA_DIR"

echo "==> 4/10. Копирование исходников"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
rsync -a --delete \
    --exclude='.venv' --exclude='__pycache__' --exclude='*.pyc' \
    --exclude='output' --exclude='.env' \
    --exclude='.playwright_browsers' \
    "$SRC_DIR/" "$APP_DIR/"

echo "==> 5/10. .env"
if [[ ! -f "$APP_DIR/.env" ]]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
    chmod 600 "$APP_DIR/.env"
    echo "    создан $APP_DIR/.env"
else
    echo "    .env уже существует — не трогаю"
fi
sed -i "s|^OUTPUT_DIR=.*|OUTPUT_DIR=$DATA_DIR/output|" "$APP_DIR/.env"
sed -i "s|^BROWSER_STATE_PATH=.*|BROWSER_STATE_PATH=$DATA_DIR/browser_state.json|" "$APP_DIR/.env"

echo "==> 6/10. Python venv + pip-зависимости"
if [[ ! -d "$APP_DIR/.venv" ]]; then
    $PYTHON -m venv "$APP_DIR/.venv"
fi
"$APP_DIR/.venv/bin/pip" install --upgrade pip --quiet
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt" --quiet

echo "==> 7/10. Playwright Chromium + системные зависимости (5-10 мин)"
export PLAYWRIGHT_BROWSERS_PATH="$PLAYWRIGHT_BROWSERS_PATH"
"$APP_DIR/.venv/bin/playwright" install --with-deps chromium

chown -R "$USER:$USER" "$APP_DIR"

echo "==> 8/10. systemd unit"
cp "$APP_DIR/deploy/mp_parser.service" /etc/systemd/system/mp_parser.service
systemctl daemon-reload
systemctl enable mp_parser

echo "==> 9/10. nginx + basic auth"
if [[ ! -f /etc/nginx/.htpasswd ]]; then
    if [[ -z "${BASIC_AUTH_USER:-}" || -z "${BASIC_AUTH_PASS:-}" ]]; then
        echo ""
        echo "    !!! Не задан логин/пароль для basic auth."
        echo "    !!! Запусти повторно с переменными:"
        echo "    !!!   BASIC_AUTH_USER=admin BASIC_AUTH_PASS='SuperSecret' bash $0"
        exit 1
    fi
    htpasswd -cbB /etc/nginx/.htpasswd "$BASIC_AUTH_USER" "$BASIC_AUTH_PASS"
    echo "    htpasswd создан для пользователя '$BASIC_AUTH_USER'"
else
    echo "    .htpasswd уже существует — не трогаю"
fi

cp "$APP_DIR/deploy/nginx.conf" /etc/nginx/sites-available/mp_parser
ln -sf /etc/nginx/sites-available/mp_parser /etc/nginx/sites-enabled/mp_parser
rm -f /etc/nginx/sites-enabled/default
nginx -t

echo "==> 10/10. Запуск сервисов"
# Принудительно сбросим storage_state — после смены логики stealth куки могут "не подходить"
if [[ -f "$DATA_DIR/browser_state.json" && "${RESET_STATE:-}" == "1" ]]; then
    rm -f "$DATA_DIR/browser_state.json"
    echo "    storage_state сброшен (RESET_STATE=1)"
fi

systemctl restart mp_parser
systemctl reload nginx || systemctl restart nginx

sleep 4
if systemctl is-active --quiet mp_parser; then
    echo "    mp_parser: OK"
else
    echo "    !!! mp_parser НЕ запустился. Логи:"
    journalctl -u mp_parser -n 30 --no-pager
    exit 1
fi

IP4=$(curl -4 -s --max-time 5 ifconfig.me 2>/dev/null || echo "<server-ip>")

cat <<EOF

==============================================
 Деплой завершён.
 URL:    http://$IP4/
 Логин:  ${BASIC_AUTH_USER:-(уже был)}

 Логи:        journalctl -u mp_parser -f
 .env:        $APP_DIR/.env
 Файлы:       $DATA_DIR/output/
 Debug:       $DATA_DIR/output/debug/
 Куки:        $DATA_DIR/browser_state.json
==============================================

ПЕРВЫЙ ПРОГОН: дольше обычного (10-20 сек на товар), браузер прогревается.
Если упирается в "Доступ ограничен" — смотри $DATA_DIR/output/debug/
там HTML и скриншот блок-страницы.

ДЛЯ СБРОСА КУКОВ перед деплоем:
  RESET_STATE=1 BASIC_AUTH_USER=... BASIC_AUTH_PASS=... bash deploy/install.sh
EOF
