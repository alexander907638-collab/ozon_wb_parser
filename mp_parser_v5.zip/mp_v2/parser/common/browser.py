"""
Менеджер headless-браузера для парсинга SPA-сайтов (Ozon/WB).

Ключевые решения:
- Один shared Chromium на всё приложение (lazy startup)
- Контекст с persistent storage_state (куки выживают рестарты)
- playwright-stealth: набор патчей для обхода bot-detection
  (navigator.webdriver, плагины, языки, WebGL fingerprint, и т.д.)
- Семафор ограничивает количество одновременных страниц
- Прогрев контекста: при первом старте заходим на главные страницы
  Ozon и WB, имитируем человеческое поведение, чтобы получить «честные» куки
- Отключение картинок/шрифтов/медиа для скорости
- Debug-режим: при сбое сохраняет HTML и скриншот страницы

Если после всего этого Ozon всё равно показывает «Доступ ограничен» —
проблема либо в IP (датацентр), либо нужна более серьёзная мера
(резидентский прокси, поведенческие паттерны).
"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from playwright.async_api import (
    async_playwright,
    Browser,
    BrowserContext,
    Page,
    TimeoutError as PWTimeoutError,
    Playwright,
)

# stealth — опциональный, импортируем безопасно
try:
    from playwright_stealth import Stealth  # type: ignore
    _HAS_STEALTH = True
except ImportError:
    _HAS_STEALTH = False


logger = logging.getLogger(__name__)


# UA реального Chrome 147 на Windows 10
DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/147.0.0.0 Safari/537.36"
)

BLOCK_RESOURCE_TYPES = {"image", "media", "font"}

BLOCK_DOMAIN_HINTS = (
    "google-analytics.com",
    "googletagmanager.com",
    "yandex.ru/metrika",
    "mc.yandex.ru",
    "doubleclick.net",
    "facebook.com",
    "criteo.com",
    "adriver",
)


# Расширенный init-script: убирает наиболее частые признаки автоматизации.
# Дополняет stealth (или заменяет, если stealth не установлен).
ANTI_DETECTION_INIT = r"""
// 1. webdriver
Object.defineProperty(navigator, 'webdriver', {get: () => undefined});

// 2. plugins (реальный Chrome имеет минимум один плагин)
Object.defineProperty(navigator, 'plugins', {
    get: () => {
        return [
            {
                0: {type: "application/x-google-chrome-pdf", suffixes: "pdf",
                    description: "Portable Document Format"},
                description: "Portable Document Format",
                filename: "internal-pdf-viewer",
                length: 1,
                name: "Chrome PDF Plugin"
            }
        ];
    }
});

// 3. languages
Object.defineProperty(navigator, 'languages', {
    get: () => ['ru-RU', 'ru', 'en-US', 'en']
});

// 4. permissions API — должна возвращать осмысленные значения
const originalQuery = window.navigator.permissions
    ? window.navigator.permissions.query
    : null;
if (originalQuery) {
    window.navigator.permissions.query = (parameters) => (
        parameters.name === 'notifications'
            ? Promise.resolve({state: Notification.permission})
            : originalQuery(parameters)
    );
}

// 5. chrome runtime
window.chrome = window.chrome || {};
window.chrome.runtime = window.chrome.runtime || {};

// 6. Hardware concurrency и device memory — реалистичные значения
Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8});
Object.defineProperty(navigator, 'deviceMemory', {get: () => 8});

// 7. WebGL fingerprint
const getParameter = WebGLRenderingContext.prototype.getParameter;
WebGLRenderingContext.prototype.getParameter = function(parameter) {
    // UNMASKED_VENDOR_WEBGL
    if (parameter === 37445) return 'Intel Inc.';
    // UNMASKED_RENDERER_WEBGL
    if (parameter === 37446) return 'Intel Iris OpenGL Engine';
    return getParameter.call(this, parameter);
};

// 8. Скрываем factory headless-маркеры
['cdc_adoQpoasnfa76pfcZLmcfl_Array',
 'cdc_adoQpoasnfa76pfcZLmcfl_Promise',
 'cdc_adoQpoasnfa76pfcZLmcfl_Symbol'].forEach(p => {
    try { delete window[p]; } catch (e) {}
});
"""


class BrowserManager:
    """Singleton-like менеджер Playwright."""

    def __init__(
        self,
        storage_state_path: Path,
        headless: bool = True,
        max_concurrent_pages: int = 2,
        slow_mo: int = 0,
        debug_dir: Path | None = None,
    ):
        self.storage_state_path = storage_state_path
        self.headless = headless
        self.max_concurrent_pages = max_concurrent_pages
        self.slow_mo = slow_mo
        self.debug_dir = debug_dir

        self._playwright: Playwright | None = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None
        self._semaphore = asyncio.Semaphore(max_concurrent_pages)
        self._start_lock = asyncio.Lock()
        self._warmed_up = False

    async def start(self) -> None:
        async with self._start_lock:
            if self._context is not None:
                return

            self._playwright = await async_playwright().start()
            launch_args = [
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--disable-features=IsolateOrigins,site-per-process",
                "--disable-site-isolation-trials",
            ]
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=launch_args,
            )

            ctx_kwargs: dict[str, Any] = {
                "user_agent": DEFAULT_UA,
                "viewport": {"width": 1366, "height": 900},
                "locale": "ru-RU",
                "timezone_id": "Europe/Moscow",
                "extra_http_headers": {
                    "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
                    "sec-ch-ua": (
                        '"Chromium";v="147", "Not?A_Brand";v="24", '
                        '"Google Chrome";v="147"'
                    ),
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": '"Windows"',
                },
            }
            if self.storage_state_path.exists():
                try:
                    ctx_kwargs["storage_state"] = str(self.storage_state_path)
                    logger.info("storage_state загружен из %s", self.storage_state_path)
                except Exception as e:
                    logger.warning("storage_state кривой: %s", e)

            self._context = await self._browser.new_context(**ctx_kwargs)

            # Применяем stealth-патчи к контексту, если установлен
            if _HAS_STEALTH:
                try:
                    stealth = Stealth()
                    await stealth.apply_stealth_async(self._context)
                    logger.info("playwright-stealth применён")
                except Exception as e:
                    logger.warning("Не применился stealth: %s", e)
            else:
                logger.warning(
                    "playwright-stealth не установлен — "
                    "используем только встроенные патчи"
                )

            # Дополнительные ручные патчи поверх stealth (или вместо него)
            await self._context.add_init_script(ANTI_DETECTION_INIT)

            # Блокировка тяжёлых ресурсов
            await self._context.route("**/*", self._route_filter)

            logger.info(
                "Playwright-контекст готов (stealth=%s, headless=%s)",
                _HAS_STEALTH, self.headless,
            )

    async def _route_filter(self, route: Any, request: Any) -> None:
        rt = request.resource_type
        url = request.url
        if rt in BLOCK_RESOURCE_TYPES:
            await route.abort()
            return
        if any(hint in url for hint in BLOCK_DOMAIN_HINTS):
            await route.abort()
            return
        await route.continue_()

    async def warmup(self) -> None:
        """
        Заходим на главные Ozon и WB. Имитируем человека:
        ждём, скроллим, чтобы JS отработал и мы получили нормальные куки.
        """
        if self._warmed_up:
            return
        await self.start()
        if not self._context:
            return

        cookies = await self._context.cookies()
        ozon_cookies = [c for c in cookies if "ozon.ru" in c.get("domain", "")]
        wb_cookies = [c for c in cookies if "wildberries" in c.get("domain", "")]

        urls_to_warmup: list[str] = []
        if not ozon_cookies:
            urls_to_warmup.append("https://www.ozon.ru/")
        if not wb_cookies:
            urls_to_warmup.append("https://www.wildberries.ru/")

        if not urls_to_warmup:
            self._warmed_up = True
            logger.info("Прогрев не нужен (куки уже есть)")
            return

        for url in urls_to_warmup:
            try:
                page = await self._context.new_page()
                await page.goto(url, wait_until="domcontentloaded", timeout=30_000)
                # имитируем человека: ждём + скроллим
                await page.wait_for_timeout(3_000)
                try:
                    await page.evaluate(
                        "window.scrollTo(0, document.body.scrollHeight / 2)"
                    )
                    await page.wait_for_timeout(1_500)
                except Exception:
                    pass
                # проверим, что не упали в "Доступ ограничен"
                title = await page.title()
                if "ограничен" in title.lower() or "доступ" in title.lower():
                    logger.warning("Прогрев %s упёрся в блок: %s", url, title)
                    await self._dump_debug(page, "warmup_block")
                else:
                    logger.info("Прогрев OK: %s (title: %s)", url, title[:60])
                await page.close()
            except Exception as e:
                logger.warning("Прогрев не удался для %s: %s", url, e)

        await self.save_state()
        self._warmed_up = True

    async def _dump_debug(self, page: Page, label: str) -> None:
        """Сохранить HTML и скриншот для диагностики."""
        if not self.debug_dir:
            return
        try:
            self.debug_dir.mkdir(parents=True, exist_ok=True)
            ts = asyncio.get_event_loop().time()
            stem = f"{label}_{int(ts)}"
            html = await page.content()
            (self.debug_dir / f"{stem}.html").write_text(html, encoding="utf-8")
            await page.screenshot(
                path=str(self.debug_dir / f"{stem}.png"),
                full_page=False,
            )
            logger.info("Debug сохранён: %s", self.debug_dir / stem)
        except Exception as e:
            logger.warning("Не удалось сохранить debug: %s", e)

    async def save_state(self) -> None:
        if not self._context:
            return
        try:
            self.storage_state_path.parent.mkdir(parents=True, exist_ok=True)
            await self._context.storage_state(path=str(self.storage_state_path))
        except Exception as e:
            logger.warning("Не удалось сохранить storage_state: %s", e)

    async def new_page(self) -> Page:
        await self.start()
        if not self._context:
            raise RuntimeError("Context не инициализирован")
        return await self._context.new_page()

    def page_slot(self) -> "PageSlot":
        return PageSlot(self)

    async def close(self) -> None:
        try:
            if self._context:
                await self.save_state()
                await self._context.close()
                self._context = None
        except Exception as e:
            logger.warning("Закрытие контекста: %s", e)
        try:
            if self._browser:
                await self._browser.close()
                self._browser = None
        except Exception as e:
            logger.warning("Закрытие браузера: %s", e)
        try:
            if self._playwright:
                await self._playwright.stop()
                self._playwright = None
        except Exception as e:
            logger.warning("Остановка playwright: %s", e)


class PageSlot:
    def __init__(self, manager: BrowserManager):
        self.manager = manager
        self.page: Page | None = None

    async def __aenter__(self) -> Page:
        await self.manager._semaphore.acquire()
        try:
            self.page = await self.manager.new_page()
            return self.page
        except Exception:
            self.manager._semaphore.release()
            raise

    async def __aexit__(self, *args: Any) -> None:
        try:
            if self.page:
                await self.page.close()
        except Exception:
            pass
        finally:
            self.manager._semaphore.release()


_global_manager: BrowserManager | None = None


def get_browser_manager(
    storage_state_path: Path | None = None,
    headless: bool = True,
    max_concurrent_pages: int = 2,
    debug_dir: Path | None = None,
) -> BrowserManager:
    global _global_manager
    if _global_manager is None:
        if storage_state_path is None:
            raise RuntimeError("Первый вызов: storage_state_path обязателен")
        _global_manager = BrowserManager(
            storage_state_path=storage_state_path,
            headless=headless,
            max_concurrent_pages=max_concurrent_pages,
            debug_dir=debug_dir,
        )
    return _global_manager
