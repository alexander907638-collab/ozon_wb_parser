"""
Парсер Q&A для Ozon через Playwright.

Стратегия:
1. Открываем https://www.ozon.ru/product/{id}/questions/
2. Проверяем — не отдал ли Ozon страницу "Доступ ограничен" (если да — debug + 0)
3. Ждём появления контейнера webListQuestions
4. Кликаем "Показать ещё", скроллим
5. Раскрываем "Ещё N ответов" внутри карточек
6. Парсим итоговый DOM через page.evaluate(JS)

Все стратегии полагаются на семантические маркеры (не на классы):
- data-widget="webListQuestions"
- data-question-id, data-answer-id

При блокировке или иной проблеме сохраняем HTML+скриншот в debug_dir
если таковой задан.
"""
from __future__ import annotations

import logging
from typing import Any

from playwright.async_api import Page, TimeoutError as PWTimeoutError

from ..common.browser import BrowserManager
from ..common.types import Product, QAItem, RateLimiter


logger = logging.getLogger(__name__)


PRODUCT_BASE = "https://www.ozon.ru"


# JS-извлекатель структурированных вопросов из готового DOM
EXTRACT_QUESTIONS_JS = r"""
() => {
    const container = document.querySelector('[data-widget="webListQuestions"]');
    if (!container) return [];

    const cards = Array.from(container.children).filter(c => {
        const txt = (c.innerText || '').trim();
        return txt.length > 10;
    });

    const dateRe = /^\d{1,2}\s+[а-яё]+\s+\d{4}$/i;
    const isJunk = t =>
        /^Лучший ответ$/i.test(t)
        || /^Вам помог этот ответ\??$/i.test(t)
        || /^(Да|Нет)$/i.test(t)
        || /^(Да|Нет)\s+\d+$/i.test(t)
        || /^Ещё \d+ ответ/i.test(t)
        || /^Еще \d+ ответ/i.test(t)
        || /^Показать (ещё|еще)/i.test(t)
        || /^\d+$/.test(t)
        || t.length < 2;

    function leafTexts(root, exclude = []) {
        const out = [];
        const walker = document.createTreeWalker(
            root, NodeFilter.SHOW_ELEMENT, {
                acceptNode(el) {
                    for (const ex of exclude) {
                        if (ex.contains(el)) return NodeFilter.FILTER_REJECT;
                    }
                    if (el.children.length === 0) return NodeFilter.FILTER_ACCEPT;
                    const allInline = Array.from(el.children).every(c =>
                        ['SPAN', 'B', 'I', 'EM', 'STRONG', 'BR', 'A'].includes(c.tagName)
                    );
                    return allInline ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                }
            }
        );
        let node;
        while ((node = walker.nextNode())) {
            const t = (node.innerText || '').trim();
            if (t.length > 0 && !isJunk(t)) out.push(t);
        }
        return out;
    }

    function parseAnswer(ansEl) {
        const id = ansEl.getAttribute('data-answer-id') || '';
        const texts = leafTexts(ansEl);
        const date = texts.find(t => dateRe.test(t)) || '';
        const nonDate = texts.filter(t => !dateRe.test(t));
        const text = nonDate.length
            ? nonDate.reduce((a, b) => a.length >= b.length ? a : b, '')
            : '';
        const idxText = nonDate.indexOf(text);
        let author = '';
        for (let i = 0; i < idxText; i++) {
            if (nonDate[i].length < 50 && nonDate[i] !== text) {
                author = nonDate[i];
                break;
            }
        }
        if (!author) {
            author = nonDate.find(t => t !== text && t.length < 50) || '';
        }
        return { id, text, author, date };
    }

    const out = [];
    const seen = new Set();

    cards.forEach(card => {
        const answerEls = Array.from(card.querySelectorAll('[data-answer-id]'));
        const answers = answerEls.map(parseAnswer);

        const dqid = card.getAttribute('data-question-id')
                  || (card.querySelector('[data-question-id]')
                      ? card.querySelector('[data-question-id]').getAttribute('data-question-id')
                      : '')
                  || '';
        const idFromAnswer = answers.length > 0 ? `q_${answers[0].id}` : '';
        const fallback = `q_idx_${out.length}`;
        const id = dqid || idFromAnswer || fallback;

        const texts = leafTexts(card, answerEls);
        const date = texts.find(t => dateRe.test(t)) || '';
        const productLink = card.querySelector('a[href*="/product/"]');
        const productUrl = productLink ? productLink.href : '';
        const productName = productLink
            ? (productLink.innerText || '').trim()
            : '';

        const productNameSet = new Set();
        if (productName) productNameSet.add(productName);

        const candidates = texts.filter(t =>
            !dateRe.test(t) && !productNameSet.has(t)
        );
        const questionText = candidates.length
            ? candidates.reduce((a, b) => a.length >= b.length ? a : b, '')
            : '';
        const qIdx = candidates.indexOf(questionText);
        let author = '';
        for (let i = qIdx + 1; i < candidates.length; i++) {
            const t = candidates[i];
            if (t.length < 60 && !t.endsWith('?') && t !== questionText) {
                author = t;
                break;
            }
        }
        if (!author) {
            author = candidates.find(t =>
                t !== questionText && t.length < 60 && !t.endsWith('?')
            ) || '';
        }

        if (!questionText) return;
        if (seen.has(id)) return;
        seen.add(id);

        out.push({
            id: String(id),
            text: questionText,
            author: author,
            date: date,
            productName: productName,
            productUrl: productUrl,
            answers: answers,
        });
    });

    return out;
}
"""


class OzonParser:
    def __init__(self, browser: BrowserManager, limiter: RateLimiter):
        self.browser = browser
        self.limiter = limiter

    async def fetch_questions(self, product: Product) -> list[QAItem]:
        await self.limiter.wait()
        url = f"{PRODUCT_BASE}/product/{product.product_id}/questions/"
        async with self.browser.page_slot() as page:
            try:
                return await self._scrape(page, url, product)
            except Exception as e:
                logger.warning("[ozon %s] %s", product.product_id, e)
                return []

    async def _scrape(
        self, page: Page, url: str, product: Product
    ) -> list[QAItem]:
        # ШАГ 1: сначала идём на главную страницу товара.
        # Это даёт Ozon выдать прогретые куки именно для этого товара,
        # а нам — естественную navigation history (referer для /questions/
        # будет /product/{id}/, как у живого пользователя, который кликнул
        # на вкладку "Вопросы").
        product_url = f"{PRODUCT_BASE}/product/{product.product_id}/"
        try:
            await page.goto(
                product_url, wait_until="domcontentloaded", timeout=45_000
            )
            await page.wait_for_timeout(2_000)
            # имитируем человека: чуть скроллим карточку
            try:
                await page.evaluate("window.scrollTo(0, 600)")
                await page.wait_for_timeout(800)
            except Exception:
                pass

            # Проверка на блокировку прямо на этой стадии
            if await self._is_blocked(page):
                logger.warning(
                    "[ozon %s] блок на странице товара",
                    product.product_id,
                )
                await self.browser._dump_debug(
                    page, f"ozon_blocked_pdp_{product.product_id}"
                )
                return []

            # Имя товара берём отсюда — на странице /questions/ его обычно нет
            if not product.name:
                try:
                    heading = page.locator(
                        '[data-widget="webProductHeading"] h1, h1'
                    ).first
                    product.name = (
                        await heading.inner_text(timeout=3_000)
                    ).strip()[:200]
                except Exception:
                    pass
        except PWTimeoutError:
            logger.warning(
                "[ozon %s] таймаут на странице товара, идём дальше",
                product.product_id,
            )

        # ШАГ 2: переходим на страницу вопросов
        await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
        await page.wait_for_timeout(2_500)

        # Проверка на блокировку уже на странице вопросов
        if await self._is_blocked(page):
            logger.warning(
                "[ozon %s] Доступ ограничен на /questions/",
                product.product_id,
            )
            await self.browser._dump_debug(
                page, f"ozon_blocked_questions_{product.product_id}"
            )
            return []

        # Закрыть плашку с куки если ещё не закрыли
        for sel in [
            'button:has-text("Принять")',
            'button:has-text("ОК")',
            'button:has-text("Согласен")',
        ]:
            try:
                btn = page.locator(sel).first
                if await btn.is_visible(timeout=1000):
                    await btn.click(timeout=1500)
                    break
            except Exception:
                pass

        # Скроллим — иногда контейнер вопросов lazy и появляется только
        # после первого скролла
        try:
            await page.evaluate("window.scrollTo(0, 400)")
            await page.wait_for_timeout(800)
        except Exception:
            pass

        # Ждём появление контейнера или ясного признака пустоты
        try:
            await page.wait_for_selector(
                '[data-widget="webListQuestions"], [data-widget*="emptyQuestions"]',
                timeout=20_000,
            )
        except PWTimeoutError:
            logger.info("[ozon %s] контейнер не появился", product.product_id)
            await self.browser._dump_debug(
                page, f"ozon_no_container_{product.product_id}"
            )
            return []

        # Подгружаем все вопросы
        await self._load_all(page)

        # Извлекаем
        try:
            raw = await page.evaluate(EXTRACT_QUESTIONS_JS)
        except Exception as e:
            logger.warning("[ozon %s] evaluate %s", product.product_id, e)
            return []

        items = self._convert(raw or [], product)
        logger.info(
            "[ozon %s] извлечено: %d вопросов, %d записей",
            product.product_id,
            len(raw or []),
            len(items),
        )
        return items

    async def _is_blocked(self, page: Page) -> bool:
        """Проверка на страницу 'Доступ ограничен'."""
        try:
            title = await page.title()
        except Exception:
            return False
        if not title:
            return False
        bad = ("ограничен", "доступ запрещен", "access denied", "blocked")
        return any(b in title.lower() for b in bad)

    async def _load_all(self, page: Page) -> None:
        prev = -1
        stable = 0
        for _ in range(50):
            try:
                count = await page.evaluate(
                    "() => document.querySelectorAll("
                    "'[data-widget=\"webListQuestions\"] > *'"
                    ").length"
                )
            except Exception:
                break

            if count == prev:
                stable += 1
                if stable >= 2:
                    break
            else:
                stable = 0
                prev = count

            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await page.wait_for_timeout(700)
            await self._click_show_more(page)
            await self._expand_more_answers(page)

    async def _click_show_more(self, page: Page) -> bool:
        for sel in [
            'button:has-text("Показать ещё")',
            'button:has-text("Показать еще")',
            'div[role="button"]:has-text("Показать ещё")',
            'div[role="button"]:has-text("Показать еще")',
        ]:
            try:
                loc = page.locator(sel).first
                if await loc.is_visible(timeout=500):
                    await loc.scroll_into_view_if_needed(timeout=1_000)
                    await loc.click(timeout=2_000)
                    await page.wait_for_timeout(1_200)
                    return True
            except Exception:
                continue
        return False

    async def _expand_more_answers(self, page: Page) -> None:
        try:
            buttons = page.locator(
                ':is(button, div[role="button"]):has-text("Ещё"), '
                ':is(button, div[role="button"]):has-text("Еще")'
            )
            count = await buttons.count()
            for i in range(min(count, 40)):
                try:
                    btn = buttons.nth(i)
                    if await btn.is_visible(timeout=200):
                        await btn.click(timeout=800)
                        await page.wait_for_timeout(120)
                except Exception:
                    continue
        except Exception:
            pass

    def _convert(
        self, raw: list[dict[str, Any]], product: Product
    ) -> list[QAItem]:
        items: list[QAItem] = []
        for q in raw:
            q_id = str(q.get("id") or "")
            if not q_id:
                continue
            answers = q.get("answers") or []
            first = answers[0] if answers else {}
            items.append(QAItem(
                marketplace="ozon",
                product_id=product.product_id,
                product_name=q.get("productName") or product.name,
                product_url=q.get("productUrl") or product.url,
                item_type="question",
                item_id=q_id,
                text=q.get("text") or "",
                author=q.get("author") or "",
                created_at=q.get("date") or "",
                answer_text=first.get("text") or "",
                answer_author=first.get("author") or "",
                answer_at=first.get("date") or "",
            ))
            for ans in answers[1:]:
                items.append(QAItem(
                    marketplace="ozon",
                    product_id=product.product_id,
                    product_name=q.get("productName") or product.name,
                    product_url=q.get("productUrl") or product.url,
                    item_type="answer",
                    item_id=str(ans.get("id") or ""),
                    text=ans.get("text") or "",
                    author=ans.get("author") or "",
                    created_at=ans.get("date") or "",
                    parent_id=q_id,
                ))
        return items
