"""
Парсер Q&A для Wildberries через Playwright.
"""
from __future__ import annotations

import logging
from typing import Any

from playwright.async_api import Page, TimeoutError as PWTimeoutError

from ..common.browser import BrowserManager
from ..common.types import Product, QAItem, RateLimiter


logger = logging.getLogger(__name__)


EXTRACT_QUESTIONS_JS = r"""
() => {
    const candidateSelectors = [
        '[data-feedback-id]',
        '[data-id][class*="question"]',
        '.feedback__list .feedback',
        'div.questions__list > *',
        '[class*="question-card"]',
        '[class*="QuestionItem"]',
        '[class*="questions"] > [class*="item"]',
    ];

    let cards = [];
    for (const sel of candidateSelectors) {
        const found = Array.from(document.querySelectorAll(sel));
        if (found.length > 0) {
            cards = found;
            break;
        }
    }

    if (cards.length === 0) {
        const all = Array.from(document.querySelectorAll('main *')).filter(el => {
            const t = (el.innerText || '').toLowerCase();
            return el.children.length > 0
                && t.length > 50
                && t.length < 5000
                && (t.includes('ответ продавца') || t.includes('ответ wildberries')
                    || t.includes('задал вопрос') || t.includes('написал'));
        });
        cards = all.filter(el =>
            !all.some(other => other !== el && other.contains(el))
        );
    }

    if (cards.length === 0) return [];

    const dateRe = /^\d{1,2}\s+[а-яё]+\s+\d{4}$/i;
    const isJunk = t =>
        /^(Лучший ответ|Полезно|Бесполезно)$/i.test(t)
        || /^(Да|Нет)\s*\d*$/i.test(t)
        || /^Ещё (\d+ )?ответ/i.test(t)
        || /^Еще (\d+ )?ответ/i.test(t)
        || /^\d+$/.test(t)
        || t.length < 2;

    function leafTexts(root) {
        const out = [];
        const walker = document.createTreeWalker(
            root, NodeFilter.SHOW_ELEMENT, {
                acceptNode(el) {
                    if (el.children.length === 0) return NodeFilter.FILTER_ACCEPT;
                    const allInline = Array.from(el.children).every(c =>
                        ['SPAN', 'B', 'I', 'EM', 'STRONG', 'BR', 'A'].includes(c.tagName)
                    );
                    return allInline ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                }
            }
        );
        let node;
        while ((node = walker.nextNode())) {
            const t = (node.innerText || '').trim();
            if (t.length > 0 && !isJunk(t)) out.push(t);
        }
        return out;
    }

    const out = [];
    cards.forEach((card, idx) => {
        const id = card.getAttribute('data-feedback-id')
                || card.getAttribute('data-id')
                || card.getAttribute('id')
                || `wb_${idx}`;
        const texts = leafTexts(card);
        if (texts.length === 0) return;

        const date = texts.find(t => dateRe.test(t)) || '';
        const nonDate = texts.filter(t => !dateRe.test(t));
        if (nonDate.length === 0) return;

        const longest = nonDate.reduce((a, b) => a.length >= b.length ? a : b, '');
        const idx2 = nonDate.indexOf(longest);
        const before = nonDate.slice(0, idx2);
        const after = nonDate.slice(idx2 + 1);

        let questionText = longest;
        let questionAuthor = before.find(t => t.length < 40) || '';

        let answerText = '';
        let answerAuthor = '';
        let answerDate = '';
        const answerMarkerIdx = nonDate.findIndex(t =>
            /ответ продавца|ответ wildberries|ответ магазина|ответ бренда/i.test(t)
        );
        if (answerMarkerIdx >= 0) {
            const afterMarker = nonDate.slice(answerMarkerIdx + 1);
            if (afterMarker.length > 0) {
                answerText = afterMarker.reduce((a, b) =>
                    a.length >= b.length ? a : b, '');
                answerAuthor = afterMarker.find(t => t !== answerText && t.length < 50) || '';
            }
        } else if (after.length > 0) {
            const longestAfter = after.reduce((a, b) =>
                a.length >= b.length ? a : b, '');
            if (longestAfter.length > 30) {
                answerText = longestAfter;
                answerAuthor = after.find(t => t !== longestAfter && t.length < 50) || '';
            }
        }
        if (answerText) {
            const ansIdx = nonDate.indexOf(answerText);
            for (let i = ansIdx + 1; i < texts.length; i++) {
                if (dateRe.test(texts[i])) { answerDate = texts[i]; break; }
            }
        }

        out.push({
            id: String(id),
            text: questionText,
            author: questionAuthor,
            date: date,
            answer_text: answerText,
            answer_author: answerAuthor,
            answer_date: answerDate,
        });
    });
    return out;
}
"""


# Извлечение imt_id и имени товара со ОТКРЫТОЙ страницы карточки товара WB.
# Параллельно пробуем несколько мест:
# 1. Атрибут data-root-id на основном контейнере (если есть)
# 2. Глобальные переменные в window (__INITIAL_STATE__, __NUXT__, и т.п.)
# 3. JSON-LD <script type="application/ld+json">
# 4. window.location и meta-теги
# Возвращает {imt, name} или null.
EXTRACT_IMT_FROM_PAGE_JS = r"""
() => {
    let imt = '';
    let name = '';

    // 1. h1 — название товара
    const h1 = document.querySelector('h1');
    if (h1) name = (h1.innerText || '').trim().slice(0, 200);

    // 2. Атрибут data-root-id или data-imt-id на любом контейнере
    const elWithRoot = document.querySelector('[data-root-id], [data-imt-id], [data-imt]');
    if (elWithRoot) {
        imt = elWithRoot.getAttribute('data-root-id')
           || elWithRoot.getAttribute('data-imt-id')
           || elWithRoot.getAttribute('data-imt')
           || '';
    }

    // 3. JSON-LD
    if (!imt || !name) {
        const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (const s of ldScripts) {
            try {
                const data = JSON.parse(s.textContent || '{}');
                if (data && typeof data === 'object') {
                    if (!name && data.name) name = String(data.name).slice(0, 200);
                    // у WB иногда лежит productID или sku
                    if (!imt && data.productID) imt = String(data.productID);
                }
            } catch (e) {}
        }
    }

    // 4. Поиск в HTML по регулярке "imtId":12345 или "root":12345
    if (!imt) {
        const html = document.documentElement.outerHTML;
        let m = html.match(/"imtId"\s*:\s*"?(\d+)"?/);
        if (m) imt = m[1];
        if (!imt) {
            m = html.match(/"root"\s*:\s*"?(\d+)"?/);
            if (m) imt = m[1];
        }
        if (!imt) {
            m = html.match(/imtId=(\d+)/);
            if (m) imt = m[1];
        }
    }

    // 5. Если не нашли — пробуем window.__NUXT__ / __NEXT_DATA__ / globals
    if (!imt) {
        try {
            const obj = window.__NUXT__ || window.__NEXT_DATA__ || window.__INITIAL_STATE__;
            if (obj) {
                const json = JSON.stringify(obj);
                const m = json.match(/"(?:imt_id|imtId|root)"\s*:\s*"?(\d+)"?/);
                if (m) imt = m[1];
            }
        } catch (e) {}
    }

    return { imt: String(imt || ''), name: String(name || '') };
}
"""


# Старый путь через card.wb.ru — оставляем как fallback, если страница товара
# почему-то не открылась.
GET_IMT_FALLBACK_JS = r"""
async (nmId) => {
    try {
        const url = `https://card.wb.ru/cards/v2/detail?appType=1&curr=rub&dest=-1257786&nm=${nmId}`;
        const r = await fetch(url, { credentials: 'omit' });
        if (!r.ok) return null;
        const j = await r.json();
        const p = (j?.data?.products || [])[0];
        if (!p) return null;
        return { imt: String(p.root || p.imt_id || ''), name: String(p.name || '') };
    } catch (e) { return null; }
}
"""


class WBParser:
    def __init__(self, browser: BrowserManager, limiter: RateLimiter):
        self.browser = browser
        self.limiter = limiter

    async def fetch_questions(
        self, product: Product, imt_id: str | None = None
    ) -> list[QAItem]:
        await self.limiter.wait()
        if not imt_id:
            imt_id = product.extra.get("imt_id") or ""

        async with self.browser.page_slot() as page:
            try:
                # ШАГ 1: открываем страницу товара. Получаем оттуда:
                # - imt_id (для построения URL вопросов)
                # - имя товара
                # - прогретые куки сессии для этого товара
                if not imt_id or not product.name:
                    pdp_url = (
                        f"https://www.wildberries.ru/catalog/"
                        f"{product.product_id}/detail.aspx"
                    )
                    try:
                        await page.goto(
                            pdp_url,
                            wait_until="domcontentloaded",
                            timeout=45_000,
                        )
                        await page.wait_for_timeout(2_500)

                        if await self._is_blocked(page):
                            logger.warning(
                                "[wb %s] блок на странице товара",
                                product.product_id,
                            )
                            await self.browser._dump_debug(
                                page, f"wb_blocked_pdp_{product.product_id}"
                            )
                            return []

                        info = await page.evaluate(EXTRACT_IMT_FROM_PAGE_JS)
                        if info:
                            if not imt_id and info.get("imt"):
                                imt_id = info["imt"]
                                logger.info(
                                    "[wb %s] imt_id со страницы товара: %s",
                                    product.product_id, imt_id,
                                )
                            if not product.name and info.get("name"):
                                product.name = info["name"]
                    except PWTimeoutError:
                        logger.warning(
                            "[wb %s] таймаут страницы товара",
                            product.product_id,
                        )

                # ШАГ 1b (fallback): если imt_id всё ещё нет — пробуем card.wb.ru
                if not imt_id:
                    try:
                        info = await page.evaluate(
                            GET_IMT_FALLBACK_JS, product.product_id
                        )
                        if info:
                            if not imt_id:
                                imt_id = info.get("imt") or ""
                            if not product.name:
                                product.name = info.get("name") or ""
                    except Exception as e:
                        logger.warning(
                            "[wb %s] card.wb.ru fallback упал: %s",
                            product.product_id, e,
                        )

                if not imt_id:
                    logger.warning(
                        "[wb %s] не получили imt_id ни одним способом",
                        product.product_id,
                    )
                    await self.browser._dump_debug(
                        page, f"wb_no_imt_{product.product_id}"
                    )
                    return []

                # ШАГ 2: переходим на страницу вопросов
                url = (
                    f"https://www.wildberries.ru/catalog/{product.product_id}"
                    f"/questions?imtId={imt_id}"
                )
                return await self._scrape(page, url, product)
            except Exception as e:
                logger.warning("[wb %s] %s", product.product_id, e)
                return []

    async def _is_blocked(self, page: Page) -> bool:
        try:
            title = await page.title()
        except Exception:
            return False
        if not title:
            return False
        bad = ("ограничен", "доступ запрещен", "access denied", "blocked")
        return any(b in title.lower() for b in bad)

    async def _scrape(
        self, page: Page, url: str, product: Product
    ) -> list[QAItem]:
        await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
        await page.wait_for_timeout(2_500)

        if await self._is_blocked(page):
            logger.warning(
                "[wb %s] страница блокировки", product.product_id
            )
            await self.browser._dump_debug(page, f"wb_blocked_{product.product_id}")
            return []

        prev = -1
        stable = 0
        for _ in range(30):
            try:
                count = await page.evaluate(
                    "() => document.querySelectorAll("
                    "'[data-feedback-id], [data-id][class*=\"question\"], "
                    ".feedback__list .feedback, [class*=\"question-card\"], "
                    "[class*=\"QuestionItem\"]'"
                    ").length"
                )
            except Exception:
                break

            if count == prev:
                stable += 1
                if stable >= 3:
                    break
            else:
                stable = 0
                prev = count

            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await page.wait_for_timeout(700)

            for sel in [
                'button:has-text("Показать ещё")',
                'button:has-text("Показать еще")',
                'button:has-text("Загрузить ещё")',
                'div[role="button"]:has-text("Показать ещё")',
            ]:
                try:
                    btn = page.locator(sel).first
                    if await btn.is_visible(timeout=300):
                        await btn.click(timeout=1_500)
                        await page.wait_for_timeout(800)
                        break
                except Exception:
                    continue

        try:
            raw = await page.evaluate(EXTRACT_QUESTIONS_JS)
        except Exception as e:
            logger.warning("[wb %s] evaluate %s", product.product_id, e)
            return []

        if not raw:
            # на всякий случай дампим
            await self.browser._dump_debug(
                page, f"wb_empty_{product.product_id}"
            )

        items = self._convert(raw or [], product)
        logger.info(
            "[wb %s] извлечено: %d записей", product.product_id, len(items)
        )
        return items

    def _convert(
        self, raw: list[dict[str, Any]], product: Product
    ) -> list[QAItem]:
        items: list[QAItem] = []
        seen = set()
        for q in raw:
            qid = str(q.get("id") or "")
            if not qid or qid in seen:
                continue
            seen.add(qid)
            items.append(QAItem(
                marketplace="wb",
                product_id=product.product_id,
                product_name=product.name,
                product_url=product.url,
                item_type="question",
                item_id=qid,
                text=q.get("text") or "",
                author=q.get("author") or "",
                created_at=q.get("date") or "",
                answer_text=q.get("answer_text") or "",
                answer_author=q.get("answer_author") or "",
                answer_at=q.get("answer_date") or "",
            ))
        return items
