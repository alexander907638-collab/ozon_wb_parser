"""TaskManager — фоновые задачи парсинга."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Literal

from parser.common.browser import BrowserManager
from parser.common.types import save_to_csv, save_to_json, today_stamp
from parser.pipeline import ParserPipeline, PipelineConfig


logger = logging.getLogger(__name__)


TaskStatus = Literal["pending", "running", "done", "error"]


@dataclass
class Task:
    id: str
    urls: list[str]
    status: TaskStatus = "pending"
    message: str = "В очереди"
    current: int = 0
    total: int = 0
    items_found: int = 0
    files: list[str] = field(default_factory=list)
    per_url_results: list[dict] = field(default_factory=list)
    created_at: str = ""
    started_at: str = ""
    finished_at: str = ""
    debug_enabled: bool = False
    error: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["urls_preview"] = [u[:80] for u in self.urls[:5]]
        d["urls_total"] = len(self.urls)
        return d


class TaskManager:
    def __init__(self, output_dir: Path, browser: BrowserManager):
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.browser = browser
        self.tasks: dict[str, Task] = {}
        self._lock = asyncio.Lock()

    def enqueue(self, urls: list[str], debug: bool = False) -> Task:
        task = Task(
            id=uuid.uuid4().hex[:12],
            urls=urls,
            total=len(urls),
            created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            debug_enabled=debug,
        )
        self.tasks[task.id] = task
        asyncio.create_task(self._run(task))
        return task

    def get(self, task_id: str) -> Task | None:
        return self.tasks.get(task_id)

    def get_recent(self, limit: int = 30) -> list[Task]:
        return sorted(
            self.tasks.values(),
            key=lambda t: t.created_at or "0",
            reverse=True,
        )[:limit]

    async def _run(self, task: Task) -> None:
        async with self._lock:
            task.status = "running"
            task.started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            task.message = "Запуск браузера..."

            try:
                config = PipelineConfig(
                    storage_state_path=Path(
                        os.getenv(
                            "BROWSER_STATE_PATH",
                            "/var/lib/mp_parser/browser_state.json",
                        )
                    ),
                    headless=os.getenv("HEADLESS", "1") not in ("0", "false"),
                    max_concurrent_pages=int(
                        os.getenv("MAX_CONCURRENT_PAGES", "2")
                    ),
                    ozon_delay=float(os.getenv("OZON_DELAY", "1.5")),
                    wb_delay=float(os.getenv("WB_DELAY", "0.5")),
                )
                pipeline = ParserPipeline(config, self.browser)

                def progress(current: int, total: int, msg: str) -> None:
                    task.current = current
                    task.total = total
                    task.message = msg

                items, results = await pipeline.run(
                    task.urls, on_progress=progress
                )

                stamp = today_stamp()
                prefix = f"task_{task.id}_{stamp}"
                csv_path = self.output_dir / f"{prefix}.csv"
                json_path = self.output_dir / f"{prefix}.json"
                save_to_csv(items, csv_path)
                save_to_json(items, json_path)

                report_path = self.output_dir / f"{prefix}_report.json"
                with report_path.open("w", encoding="utf-8") as f:
                    json.dump(
                        [asdict(r) for r in results], f,
                        ensure_ascii=False, indent=2,
                    )

                task.files = [csv_path.name, json_path.name, report_path.name]
                task.per_url_results = [asdict(r) for r in results]
                task.items_found = len(items)
                task.status = "done"
                task.finished_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                ok_urls = sum(1 for r in results if r.success)
                err_urls = len(results) - ok_urls
                type_counts = Counter(it.item_type for it in items)
                breakdown = ", ".join(
                    f"{t}: {c}" for t, c in type_counts.most_common()
                )
                task.message = (
                    f"Готово: {len(items)} записей "
                    f"({breakdown or '—'}). "
                    f"URL: {ok_urls} ок, {err_urls} с ошибками."
                )
            except Exception as e:
                logger.exception("Task %s failed", task.id)
                task.status = "error"
                task.error = f"{type(e).__name__}: {e}"
                task.message = f"Ошибка: {e}"
                task.finished_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def load_items_from_file(self, filename: str) -> list[dict]:
        path = self.output_dir / filename
        if not path.exists() or not path.is_file():
            return []
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except (json.JSONDecodeError, OSError):
            pass
        return []
