"""FastAPI приложение."""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from parser.common.browser import BrowserManager
from parser.common.urls import detect_marketplace, split_lines

from .tasks import TaskManager


load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


BASE_DIR = Path(__file__).parent
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "output"))
BROWSER_STATE_PATH = Path(
    os.getenv("BROWSER_STATE_PATH", "/var/lib/mp_parser/browser_state.json")
)


# ---------- Lifespan: управление BrowserManager ----------

browser_manager: BrowserManager | None = None
task_manager: TaskManager | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Старт/стоп Playwright."""
    global browser_manager, task_manager

    logger.info("Старт BrowserManager...")
    browser_manager = BrowserManager(
        storage_state_path=BROWSER_STATE_PATH,
        headless=os.getenv("HEADLESS", "1") not in ("0", "false"),
        max_concurrent_pages=int(os.getenv("MAX_CONCURRENT_PAGES", "2")),
    )
    # Не стартуем сразу — подождём первого запроса (lazy)
    task_manager = TaskManager(OUTPUT_DIR, browser_manager)

    try:
        yield
    finally:
        logger.info("Завершение BrowserManager...")
        if browser_manager:
            try:
                await browser_manager.close()
            except Exception as e:
                logger.warning("Ошибка при закрытии браузера: %s", e)


app = FastAPI(
    title="MP Q&A Parser (Playwright)",
    docs_url=None,
    redoc_url=None,
    lifespan=lifespan,
)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")


def _manager() -> TaskManager:
    if task_manager is None:
        raise HTTPException(503, "Сервис не инициализирован")
    return task_manager


# ---------- Pages ----------

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    tasks = [t.to_dict() for t in _manager().get_recent()]
    return templates.TemplateResponse(
        request, "index.html", {"tasks": tasks}
    )


@app.get("/task/{task_id}", response_class=HTMLResponse)
async def task_detail(request: Request, task_id: str):
    task = _manager().get(task_id)
    if not task:
        raise HTTPException(404, "Задача не найдена")

    items_file = next(
        (f for f in task.files if f.endswith(".json") and "report" not in f),
        None,
    )
    items = _manager().load_items_from_file(items_file) if items_file else []
    return templates.TemplateResponse(
        request,
        "task_detail.html",
        {
            "task": task.to_dict(),
            "items_total": len(items),
            "items_file": items_file,
        },
    )


# ---------- API ----------

@app.post("/run")
async def run_parser(
    urls_text: str = Form(""),
    urls_file: UploadFile | None = File(None),
    debug: str = Form(""),
):
    parts: list[str] = []
    if urls_text:
        parts.append(urls_text)
    if urls_file and urls_file.filename:
        try:
            raw = (await urls_file.read()).decode("utf-8", errors="ignore")
            parts.append(raw)
        except Exception as e:
            raise HTTPException(400, f"Не удалось прочитать файл: {e}")

    combined_text = "\n".join(parts)
    urls = split_lines(combined_text)
    if not urls:
        raise HTTPException(400, "Не передано ни одного URL")

    for u in urls:
        if detect_marketplace(u) is None:
            raise HTTPException(
                400,
                f"URL не относится к Ozon/WB: {u}. "
                f"Поддерживаются ozon.ru и wildberries.ru",
            )

    debug_enabled = debug.strip().lower() in ("on", "true", "1", "yes")
    task = _manager().enqueue(urls, debug=debug_enabled)
    return RedirectResponse(f"/task/{task.id}", status_code=303)


@app.get("/api/tasks")
async def api_tasks() -> JSONResponse:
    return JSONResponse([t.to_dict() for t in _manager().get_recent()])


@app.get("/api/tasks/{task_id}")
async def api_task(task_id: str) -> JSONResponse:
    task = _manager().get(task_id)
    if not task:
        raise HTTPException(404, "Не найдена")
    return JSONResponse(task.to_dict())


@app.get("/api/tasks/{task_id}/items")
async def api_task_items(
    task_id: str,
    page: int = 1,
    per_page: int = 50,
    item_type: str = "",
    search: str = "",
) -> JSONResponse:
    task = _manager().get(task_id)
    if not task:
        raise HTTPException(404, "Не найдена")

    items_file = next(
        (f for f in task.files if f.endswith(".json") and "report" not in f),
        None,
    )
    if not items_file:
        return JSONResponse(
            {"items": [], "total": 0, "page": page, "per_page": per_page}
        )

    all_items = _manager().load_items_from_file(items_file)
    filtered = all_items
    if item_type:
        filtered = [i for i in filtered if i.get("item_type") == item_type]
    if search:
        s = search.lower()
        filtered = [
            i for i in filtered
            if s in (i.get("text") or "").lower()
            or s in (i.get("answer_text") or "").lower()
            or s in (i.get("author") or "").lower()
        ]

    total = len(filtered)
    per_page = max(10, min(200, per_page))
    page = max(1, page)
    start = (page - 1) * per_page
    end = start + per_page

    from collections import Counter
    type_counts = dict(Counter(i.get("item_type", "") for i in all_items))

    return JSONResponse({
        "items": filtered[start:end],
        "total": total,
        "total_unfiltered": len(all_items),
        "type_counts": type_counts,
        "page": page,
        "per_page": per_page,
        "total_pages": max(1, (total + per_page - 1) // per_page),
    })


@app.get("/files/{name}")
async def get_file(name: str):
    if "/" in name or ".." in name or "\\" in name:
        raise HTTPException(400, "Bad filename")
    path = OUTPUT_DIR / name
    if not path.exists() or not path.is_file():
        raise HTTPException(404, "Файл не найден")
    return FileResponse(path, filename=name)


@app.get("/healthz")
async def healthz():
    return {"status": "ok"}
