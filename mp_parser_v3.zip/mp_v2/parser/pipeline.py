"""
Pipeline парсинга Q&A через Playwright.

Один вход — список URL (короткие/длинные, Ozon/WB вперемешку).
Один выход — список QAItem.

Использует один shared BrowserManager (chromium с persistent storage_state).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .common.browser import BrowserManager
from .common.types import Product, QAItem, RateLimiter
from .common.urls import (
    detect_marketplace,
    is_ozon_short,
    parse_ozon_canonical,
    parse_url,
    parse_wb,
)
from .ozon import OzonParser
from .wb import WBParser


logger = logging.getLogger(__name__)


ProgressCallback = Callable[[int, int, str], None]


@dataclass
class ParseResult:
    url: str
    success: bool
    product_id: str = ""
    marketplace: str = ""
    items_count: int = 0
    error: str = ""


@dataclass
class PipelineConfig:
    """Конфиг пайплайна."""
    storage_state_path: Path = Path("/tmp/mp_browser_state.json")
    headless: bool = True
    max_concurrent_pages: int = 2
    ozon_delay: float = 1.5
    wb_delay: float = 0.5
    debug_dir: str | None = None  # пока не используется


class ParserPipeline:
    """Главный оркестратор."""

    def __init__(self, config: PipelineConfig, browser: BrowserManager):
        self.config = config
        self.browser = browser

    async def run(
        self,
        urls: list[str],
        on_progress: ProgressCallback | None = None,
    ) -> tuple[list[QAItem], list[ParseResult]]:
        all_items: list[QAItem] = []
        results: list[ParseResult] = []

        ozon_limiter = RateLimiter(self.config.ozon_delay)
        wb_limiter = RateLimiter(self.config.wb_delay)

        ozon_parser = OzonParser(self.browser, ozon_limiter)
        wb_parser = WBParser(self.browser, wb_limiter)

        # Прогрев (получение базовых куков, если контекст пустой)
        if on_progress:
            on_progress(0, len(urls), "Прогрев браузера...")
        await self.browser.warmup()

        total = len(urls)
        for i, raw_url in enumerate(urls, start=1):
            if on_progress:
                on_progress(i, total, f"Обработка {raw_url[:60]}")

            result = ParseResult(url=raw_url, success=False)
            try:
                items = await self._process_one(
                    raw_url, ozon_parser, wb_parser
                )
                all_items.extend(items)
                result.success = True
                result.items_count = len(items)
                if items:
                    result.product_id = items[0].product_id
                    result.marketplace = items[0].marketplace
                else:
                    parsed = await self._safe_parse(raw_url)
                    if parsed:
                        result.product_id = parsed.product_id
                        result.marketplace = parsed.marketplace
            except Exception as e:
                logger.exception(
                    "Ошибка при обработке %s: %s", raw_url, e
                )
                result.error = f"{type(e).__name__}: {e}"

            results.append(result)

        # Сохраняем накопленный storage_state (куки)
        await self.browser.save_state()

        if on_progress:
            on_progress(
                total, total,
                f"Готово: {len(all_items)} записей из {total} URL",
            )

        return all_items, results

    async def _process_one(
        self,
        raw_url: str,
        ozon_parser: OzonParser,
        wb_parser: WBParser,
    ) -> list[QAItem]:
        parsed = await self._safe_parse(raw_url)
        if parsed is None:
            raise ValueError(f"Не распознан URL маркетплейса: {raw_url}")

        if parsed.marketplace == "ozon":
            product = Product(
                marketplace="ozon",
                product_id=parsed.product_id,
                name="",
                url=parsed.canonical_url,
            )
            return await ozon_parser.fetch_questions(product)

        if parsed.marketplace == "wb":
            product = Product(
                marketplace="wb",
                product_id=parsed.product_id,
                name="",
                url=parsed.canonical_url,
                extra={"imt_id": parsed.imt_id},
            )
            return await wb_parser.fetch_questions(
                product, imt_id=parsed.imt_id or None
            )

        return []

    async def _safe_parse(self, raw_url: str):
        """
        Распарсить URL. Если короткая ссылка Ozon — резолвим её через
        отдельную страницу браузера (HEAD-навигация, чтобы дойти до final URL).
        """
        parsed = parse_url(raw_url)
        if parsed:
            return parsed

        if detect_marketplace(raw_url) == "ozon" and is_ozon_short(raw_url):
            try:
                async with self.browser.page_slot() as page:
                    # Быстро: только HEAD, или goto без ожидания всего DOM
                    response = await page.goto(
                        raw_url,
                        wait_until="commit",  # только дождаться редиректа
                        timeout=20_000,
                    )
                    final_url = page.url or (response.url if response else raw_url)
                    resolved = parse_ozon_canonical(final_url)
                    if resolved:
                        return resolved
            except Exception as e:
                logger.warning("Резолв %s упал: %s", raw_url, e)

        return None
