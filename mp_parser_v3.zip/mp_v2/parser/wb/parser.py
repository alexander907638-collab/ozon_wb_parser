"""
Парсер Q&A для Wildberries через Playwright.

Открываем https://www.wildberries.ru/catalog/{nmId}/questions?imtId={imtId}
Ждём появления вопросов в DOM, скроллим/кликаем "загрузить ещё", извлекаем.

WB не имеет публичного REST для вопросов, но на странице вопросов JS подгружает
список через свой внутренний API и рендерит в DOM. Парсим финальный DOM.

ВАЖНО: WB иногда требует imtId в URL — без него отдаёт страницу с 404 либо
страницу карточки товара без блока вопросов. imtId извлекаем либо из URL,
либо через API card.wb.ru/cards/v2/detail (сделаем через тот же page).
"""
from __future__ import annotations

import logging
from typing import Any

from playwright.async_api import Page, TimeoutError as PWTimeoutError

from ..common.browser import BrowserManager
from ..common.types import Product, QAItem, RateLimiter


logger = logging.getLogger(__name__)


# JS-извлекатель: ищет блоки с вопросами по разным семантическим маркерам,
# которые WB любит использовать. Нет надежды на стабильные классы,
# поэтому ищем шире: текстовые блоки внутри контейнеров с "question" в роле/aria.
EXTRACT_QUESTIONS_JS = r"""
() => {
    // У WB на 2026-04 контейнеры:
    //   <div class="...questions__list..."> или с data-feedback-id
    // Но переменчиво — пробуем несколько селекторов.

    const candidateSelectors = [
        '[data-feedback-id]',
        '[data-id][class*="question"]',
        '.feedback__list .feedback',
        'div.questions__list > *',
        '[class*="question-card"]',
        '[class*="QuestionItem"]',
        // generic — если карточки лежат как прямые дети контейнера questions
        '[class*="questions"] > [class*="item"]',
    ];

    let cards = [];
    for (const sel of candidateSelectors) {
        const found = Array.from(document.querySelectorAll(sel));
        if (found.length > 0) {
            cards = found;
            break;
        }
    }

    // Запасной путь: ищем блоки, у которых есть и блок-вопрос, и блок-ответ
    if (cards.length === 0) {
        // Любой div, в котором есть "Ответ" / "Спросил" / characteristic для WB
        const all = Array.from(document.querySelectorAll('main *')).filter(el => {
            const t = (el.innerText || '').toLowerCase();
            return el.children.length > 0
                && t.length > 50
                && t.length < 5000
                && (t.includes('ответ продавца') || t.includes('ответ wildberries')
                    || t.includes('задал вопрос') || t.includes('написал'));
        });
        // Берём только самые маленькие (карточки), исключая контейнеры,
        // которые содержат другие найденные.
        cards = all.filter(el =>
            !all.some(other => other !== el && other.contains(el))
        );
    }

    if (cards.length === 0) return [];

    const dateRe = /^\d{1,2}\s+[а-яё]+\s+\d{4}$/i;
    const isJunk = t =>
        /^(Лучший ответ|Полезно|Бесполезно)$/i.test(t)
        || /^(Да|Нет)\s*\d*$/i.test(t)
        || /^Ещё (\d+ )?ответ/i.test(t)
        || /^Еще (\d+ )?ответ/i.test(t)
        || /^\d+$/.test(t)
        || t.length < 2;

    function leafTexts(root) {
        const out = [];
        const walker = document.createTreeWalker(
            root, NodeFilter.SHOW_ELEMENT, {
                acceptNode(el) {
                    if (el.children.length === 0) return NodeFilter.FILTER_ACCEPT;
                    const allInline = Array.from(el.children).every(c =>
                        ['SPAN', 'B', 'I', 'EM', 'STRONG', 'BR', 'A'].includes(c.tagName)
                    );
                    return allInline ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                }
            }
        );
        let node;
        while ((node = walker.nextNode())) {
            const t = (node.innerText || '').trim();
            if (t.length > 0 && !isJunk(t)) out.push(t);
        }
        return out;
    }

    const out = [];
    cards.forEach((card, idx) => {
        const id = card.getAttribute('data-feedback-id')
                || card.getAttribute('data-id')
                || card.getAttribute('id')
                || `wb_${idx}`;
        const texts = leafTexts(card);
        if (texts.length === 0) return;

        const date = texts.find(t => dateRe.test(t)) || '';
        const nonDate = texts.filter(t => !dateRe.test(t));
        if (nonDate.length === 0) return;

        // Самый длинный текст — обычно вопрос или ответ
        // На карточке вопроса обычно: автор → текст вопроса → "Ответ продавца" → текст ответа
        const longest = nonDate.reduce((a, b) => a.length >= b.length ? a : b, '');

        // Делим на "до longest" и "после longest"
        const idx2 = nonDate.indexOf(longest);
        const before = nonDate.slice(0, idx2);
        const after = nonDate.slice(idx2 + 1);

        // Текст вопроса = longest (если в before нет другого длинного)
        // ИЛИ если после longest есть пометка "Ответ продавца" + ещё длинный — тогда
        // longest это вопрос, а в after — ответ.
        let questionText = longest;
        let questionAuthor = before.find(t => t.length < 40) || '';

        // Поиск ответа: длинный кусок после longest, либо после маркера "Ответ"
        let answerText = '';
        let answerAuthor = '';
        let answerDate = '';
        const answerMarkerIdx = nonDate.findIndex(t =>
            /ответ продавца|ответ wildberries|ответ магазина|ответ бренда/i.test(t)
        );
        if (answerMarkerIdx >= 0) {
            const afterMarker = nonDate.slice(answerMarkerIdx + 1);
            if (afterMarker.length > 0) {
                answerText = afterMarker.reduce((a, b) =>
                    a.length >= b.length ? a : b, '');
                answerAuthor = afterMarker.find(t => t !== answerText && t.length < 50) || '';
            }
        } else if (after.length > 0) {
            // длиннейший после questionText
            const longestAfter = after.reduce((a, b) =>
                a.length >= b.length ? a : b, '');
            if (longestAfter.length > 30) {
                answerText = longestAfter;
                answerAuthor = after.find(t => t !== longestAfter && t.length < 50) || '';
            }
        }
        // Дата ответа — после блока с answerText
        if (answerText) {
            const ansIdx = nonDate.indexOf(answerText);
            for (let i = ansIdx + 1; i < texts.length; i++) {
                if (dateRe.test(texts[i])) { answerDate = texts[i]; break; }
            }
        }

        out.push({
            id: String(id),
            text: questionText,
            author: questionAuthor,
            date: date,
            answer_text: answerText,
            answer_author: answerAuthor,
            answer_date: answerDate,
        });
    });
    return out;
}
"""


# JS для получения imt_id через card.wb.ru — выполняется в контексте страницы
GET_IMT_JS = r"""
async (nmId) => {
    try {
        const url = `https://card.wb.ru/cards/v2/detail?appType=1&curr=rub&dest=-1257786&nm=${nmId}`;
        const r = await fetch(url, { credentials: 'omit' });
        if (!r.ok) return null;
        const j = await r.json();
        const p = (j?.data?.products || [])[0];
        if (!p) return null;
        return { imt: String(p.root || p.imt_id || ''), name: String(p.name || '') };
    } catch (e) { return null; }
}
"""


class WBParser:
    """Парсер вопросов с WB через Playwright."""

    def __init__(self, browser: BrowserManager, limiter: RateLimiter):
        self.browser = browser
        self.limiter = limiter

    async def fetch_questions(
        self, product: Product, imt_id: str | None = None
    ) -> list[QAItem]:
        await self.limiter.wait()

        if not imt_id:
            imt_id = product.extra.get("imt_id") or ""

        async with self.browser.page_slot() as page:
            try:
                # дополучаем imt_id и имя товара через card.wb.ru,
                # выполняя fetch внутри страницы (чтобы не светить наш ip
                # в отдельных запросах, плюс куки уже там)
                if not imt_id or not product.name:
                    await page.goto(
                        "https://www.wildberries.ru/",
                        wait_until="domcontentloaded",
                        timeout=30_000,
                    )
                    info = await page.evaluate(GET_IMT_JS, product.product_id)
                    if info:
                        if not imt_id:
                            imt_id = info.get("imt") or ""
                        if not product.name:
                            product.name = info.get("name") or ""

                if not imt_id:
                    logger.warning(
                        "[wb %s] не получили imt_id", product.product_id
                    )
                    return []

                url = (
                    f"https://www.wildberries.ru/catalog/{product.product_id}"
                    f"/questions?imtId={imt_id}"
                )
                return await self._scrape(page, url, product)
            except Exception as e:
                logger.warning("[wb %s] %s", product.product_id, e)
                return []

    async def _scrape(
        self, page: Page, url: str, product: Product
    ) -> list[QAItem]:
        await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
        # Дать JS отрендерить вопросы
        await page.wait_for_timeout(2_500)

        # Скроллим, чтобы триггернуть lazy-load
        prev = -1
        stable = 0
        for _ in range(30):
            try:
                count = await page.evaluate(
                    "() => document.querySelectorAll("
                    "'[data-feedback-id], [data-id][class*=\"question\"], "
                    ".feedback__list .feedback, [class*=\"question-card\"], "
                    "[class*=\"QuestionItem\"]'"
                    ").length"
                )
            except Exception:
                break

            if count == prev:
                stable += 1
                if stable >= 3:
                    break
            else:
                stable = 0
                prev = count

            await page.evaluate(
                "window.scrollTo(0, document.body.scrollHeight)"
            )
            await page.wait_for_timeout(700)

            # клик по "загрузить ещё" если есть
            for sel in [
                'button:has-text("Показать ещё")',
                'button:has-text("Показать еще")',
                'button:has-text("Загрузить ещё")',
                'div[role="button"]:has-text("Показать ещё")',
            ]:
                try:
                    btn = page.locator(sel).first
                    if await btn.is_visible(timeout=300):
                        await btn.click(timeout=1_500)
                        await page.wait_for_timeout(800)
                        break
                except Exception:
                    continue

        try:
            raw = await page.evaluate(EXTRACT_QUESTIONS_JS)
        except Exception as e:
            logger.warning("[wb %s] evaluate %s", product.product_id, e)
            return []

        items = self._convert(raw or [], product)
        logger.info(
            "[wb %s] извлечено: %d записей", product.product_id, len(items)
        )
        return items

    def _convert(
        self, raw: list[dict[str, Any]], product: Product
    ) -> list[QAItem]:
        items: list[QAItem] = []
        seen = set()
        for q in raw:
            qid = str(q.get("id") or "")
            if not qid or qid in seen:
                continue
            seen.add(qid)
            items.append(QAItem(
                marketplace="wb",
                product_id=product.product_id,
                product_name=product.name,
                product_url=product.url,
                item_type="question",
                item_id=qid,
                text=q.get("text") or "",
                author=q.get("author") or "",
                created_at=q.get("date") or "",
                answer_text=q.get("answer_text") or "",
                answer_author=q.get("answer_author") or "",
                answer_at=q.get("answer_date") or "",
            ))
        return items
