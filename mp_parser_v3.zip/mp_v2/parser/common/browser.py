"""
Менеджер headless-браузера для парсинга SPA-сайтов (Ozon/WB).

Ключевые решения:
- Один shared Chromium на всё приложение (lazy startup)
- Контекст с persistent storage_state (куки выживают рестарты)
- Семафор: ограничение количества одновременных страниц (по умолчанию 2)
- Автоматический "прогрев" контекста: при первом старте заходим на главные страницы
  Ozon и WB, чтобы аккуратно получить куки до начала парсинга
- Ретраи на сетевых таймаутах
- Отключаем картинки/шрифты/медиа для экономии трафика и времени
"""
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

from playwright.async_api import (
    async_playwright,
    Browser,
    BrowserContext,
    Page,
    TimeoutError as PWTimeoutError,
    Playwright,
)


logger = logging.getLogger(__name__)


# реальный UA Chrome 147 на Windows
DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/147.0.0.0 Safari/537.36"
)

# что блокируем при загрузке страниц (картинки и медиа не нужны для парсинга)
BLOCK_RESOURCE_TYPES = {"image", "media", "font"}

# домены, реклама/трекинг с которых не нужны
BLOCK_DOMAIN_HINTS = (
    "google-analytics.com",
    "googletagmanager.com",
    "yandex.ru/metrika",
    "mc.yandex.ru",
    "doubleclick.net",
    "facebook.com",
    "criteo.com",
)


class BrowserManager:
    """
    Singleton-like менеджер Playwright-контекста.
    Использовать через async-методы start() и new_page().
    """

    def __init__(
        self,
        storage_state_path: Path,
        headless: bool = True,
        max_concurrent_pages: int = 2,
        slow_mo: int = 0,
    ):
        self.storage_state_path = storage_state_path
        self.headless = headless
        self.max_concurrent_pages = max_concurrent_pages
        self.slow_mo = slow_mo

        self._playwright: Playwright | None = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None
        self._semaphore = asyncio.Semaphore(max_concurrent_pages)
        self._start_lock = asyncio.Lock()
        self._warmed_up = False

    async def start(self) -> None:
        """Запустить Playwright + Chromium + Context. Идемпотентно."""
        async with self._start_lock:
            if self._context is not None:
                return

            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=[
                    "--no-sandbox",
                    "--disable-blink-features=AutomationControlled",
                    "--disable-dev-shm-usage",
                ],
            )

            # Если есть сохранённый storage_state — поднимаем контекст с ним
            ctx_kwargs: dict[str, Any] = {
                "user_agent": DEFAULT_UA,
                "viewport": {"width": 1366, "height": 900},
                "locale": "ru-RU",
                "timezone_id": "Europe/Moscow",
                "extra_http_headers": {
                    "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
                },
            }
            if self.storage_state_path.exists():
                try:
                    ctx_kwargs["storage_state"] = str(self.storage_state_path)
                    logger.info("Загружен storage_state из %s", self.storage_state_path)
                except Exception as e:
                    logger.warning("storage_state кривой, игнорю: %s", e)

            self._context = await self._browser.new_context(**ctx_kwargs)

            # Глобальный route-фильтр: блокируем тяжёлые ресурсы
            await self._context.route("**/*", self._route_filter)

            # Анти-detection: убираем navigator.webdriver
            await self._context.add_init_script(
                """
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [1, 2, 3, 4, 5]
                });
                Object.defineProperty(navigator, 'languages', {
                    get: () => ['ru-RU', 'ru', 'en-US', 'en']
                });
                """
            )

            logger.info("Playwright-контекст готов")

    async def _route_filter(self, route: Any, request: Any) -> None:
        """Блокировка картинок, шрифтов, аналитики."""
        rt = request.resource_type
        url = request.url

        if rt in BLOCK_RESOURCE_TYPES:
            await route.abort()
            return
        if any(hint in url for hint in BLOCK_DOMAIN_HINTS):
            await route.abort()
            return

        await route.continue_()

    async def warmup(self) -> None:
        """
        Открыть Ozon и WB по разу — чтобы получить базовые куки сессии.
        Делаем один раз при старте контекста (если storage_state пустой).
        """
        if self._warmed_up:
            return
        await self.start()

        if not self._context:
            return

        # Если уже есть куки — прогрев не нужен
        cookies = await self._context.cookies()
        if any(c.get("domain", "").endswith("ozon.ru") for c in cookies):
            self._warmed_up = True
            logger.info("Куки Ozon уже есть, прогрев не нужен")
            return

        warmup_urls = [
            "https://www.ozon.ru/",
            "https://www.wildberries.ru/",
        ]
        for url in warmup_urls:
            try:
                page = await self._context.new_page()
                await page.goto(url, wait_until="domcontentloaded", timeout=30_000)
                await page.wait_for_timeout(2_000)  # дать JS немного поработать
                await page.close()
                logger.info("Прогрев OK: %s", url)
            except Exception as e:
                logger.warning("Прогрев не удался для %s: %s", url, e)

        await self.save_state()
        self._warmed_up = True

    async def save_state(self) -> None:
        """Сохранить storage_state (куки + localStorage) на диск."""
        if not self._context:
            return
        try:
            self.storage_state_path.parent.mkdir(parents=True, exist_ok=True)
            await self._context.storage_state(path=str(self.storage_state_path))
            logger.debug("Storage state сохранён в %s", self.storage_state_path)
        except Exception as e:
            logger.warning("Не удалось сохранить storage_state: %s", e)

    async def new_page(self) -> Page:
        """
        Получить новую страницу. Использовать через async-with через context manager.
        Семафор ограничивает количество одновременных страниц.
        """
        await self.start()
        if not self._context:
            raise RuntimeError("Context не инициализирован")
        return await self._context.new_page()

    def page_slot(self) -> "PageSlot":
        """Контекст-менеджер: захватываем семафор и страницу одним with-ом."""
        return PageSlot(self)

    async def close(self) -> None:
        """Грейсфул-шатдаун."""
        try:
            if self._context:
                await self.save_state()
                await self._context.close()
                self._context = None
        except Exception as e:
            logger.warning("Ошибка при закрытии контекста: %s", e)

        try:
            if self._browser:
                await self._browser.close()
                self._browser = None
        except Exception as e:
            logger.warning("Ошибка при закрытии браузера: %s", e)

        try:
            if self._playwright:
                await self._playwright.stop()
                self._playwright = None
        except Exception as e:
            logger.warning("Ошибка при остановке Playwright: %s", e)


class PageSlot:
    """Async-контекст: семафор + page. Гарантирует close() даже при ошибке."""

    def __init__(self, manager: BrowserManager):
        self.manager = manager
        self.page: Page | None = None

    async def __aenter__(self) -> Page:
        await self.manager._semaphore.acquire()
        try:
            self.page = await self.manager.new_page()
            return self.page
        except Exception:
            self.manager._semaphore.release()
            raise

    async def __aexit__(self, *args: Any) -> None:
        try:
            if self.page:
                await self.page.close()
        except Exception:
            pass
        finally:
            self.manager._semaphore.release()


# Глобальный singleton — один на процесс приложения
_global_manager: BrowserManager | None = None


def get_browser_manager(
    storage_state_path: Path | None = None,
    headless: bool = True,
    max_concurrent_pages: int = 2,
) -> BrowserManager:
    """Получить (или создать) глобальный BrowserManager."""
    global _global_manager
    if _global_manager is None:
        if storage_state_path is None:
            raise RuntimeError(
                "При первом вызове storage_state_path обязателен"
            )
        _global_manager = BrowserManager(
            storage_state_path=storage_state_path,
            headless=headless,
            max_concurrent_pages=max_concurrent_pages,
        )
    return _global_manager
